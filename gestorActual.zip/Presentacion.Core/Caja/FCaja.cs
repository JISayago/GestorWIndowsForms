﻿using Presentacion.Core.Movimiento;
using Presentacion.FormulariosBase.Helpers;
using Servicios.Helpers.Sistema.Rol;
using Servicios.LogicaNegocio.Caja;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion.Core.Caja
{
    public partial class FCaja : FBase.FBase
    {
        public CajaServicio cajaServicio;



        public FCaja()
        {
            cajaServicio = new CajaServicio();

            InitializeComponent();
        }

        private void btnAbrirCaja_Click(object sender, EventArgs e)
        {
            if (!AuthHelper.Tiene("Caja.Abrir"))
            {
                MostrarError("No Cuenta con las credenciales necesarias para abrir la caja");
                //MessageBox.Show("No Cuenta con las credenciales necesarias para abrir la caja");
                return;
            }
            var FCajaAbrir = new FCajaAbrir(TipoOperacion.Abrir);

            var result = FCajaAbrir.ShowDialog();
            if (result == DialogResult.OK)
            {
                Exito("Caja Abierta correctamente.\n Saldo Actual: $" + FCajaAbrir.SaldoApertura);
                //MessageBox.Show($"Caja Abierta correctamente.\n Saldo Actual: ${FCajaAbrir.SaldoApertura} ");
                InicializarEstadoCaja();
            }
        }

        private void btnCerrarCaja_Click(object sender, EventArgs e)
        {
            if (!AuthHelper.Tiene("Caja.Cerrar"))
            {
                MostrarError("No Cuenta con las credenciales necesarias para cerrar la caja");
                //MessageBox.Show("No Cuenta con las credenciales necesarias para cerrar la caja");
                return;
            }
            var FCerrarCaja = new FCajaAbrir(TipoOperacion.Cerrar);

            var result = FCerrarCaja.ShowDialog();
            if (result == DialogResult.OK)
            {
                Exito($"Caja Cerrada correctamente.\n Saldo Final: ${FCerrarCaja.SaldoFinal}");
                //MessageBox.Show($"Caja Cerrada correctamente.\n Saldo Final: ${FCerrarCaja.SaldoFinal} ");
                InicializarEstadoCaja();
            }
        }

        private void InicializarEstadoCaja()
        {
            var cajaInicial = cajaServicio.EstadoInicioCaja();
            if (!cajaInicial.EstaCerrada)
            {
                btnAbrirCaja.Enabled = false;
                btnCerrarCaja.Enabled = true;
                lblSaldoCaja.Text = cajaInicial.SaldoActual.ToString("C");
                if (cajaInicial.SaldoActual > 0)
                {
                    lblSaldoCaja.ForeColor = Color.Green;
                }
                else
                {
                    lblSaldoCaja.ForeColor = Color.Red;
                }
            }
            else
            {
                var x = 0.00m;
                btnCerrarCaja.Enabled = false;
                btnAbrirCaja.Enabled = true;
                lblSaldoCaja.Text = x.ToString("C");
            }
            lblEstadoCaja.Text = !cajaInicial.EstaCerrada ? "CAJA ABIERTA" : "CAJA CERRADA";
            pbEstadoCaja.Image = cajaInicial.EstaCerrada
                ? Constantes.Imagenes.ImgCajaCerrada
                : Constantes.Imagenes.ImgCajaAbierta;
        }
        private void FCaja_Load(object sender, EventArgs e)
        {
            InicializarEstadoCaja();
        }


        private void btnConsultarCajas_Click(object sender, EventArgs e)
        {
            if (!AuthHelper.Tiene("Caja.VerMovimientos"))
            {
                MostrarError("No Cuenta con las credenciales necesarias para ver los movimientos de la caja");
                //MessageBox.Show("No Cuenta con las credenciales necesarias para ver los movimientos de la caja");
                return;
            }
            var formConsultaCajas = new FCajaConsulta();
            formConsultaCajas.ShowDialog();
        }

        private void btnConsultarMovimientos_Click(object sender, EventArgs e)
        {
            if (!AuthHelper.Tiene("Caja.VerMovimientos"))
            {
                MostrarError("No Cuenta con las credenciales necesarias para ver los movimientos de la caja");
                //MessageBox.Show("No Cuenta con las credenciales necesarias para ver los movimientos de la caja");
                return;
            }
            var fmov = new FMovimientoConsulta();
            fmov.ShowDialog();
            // debería abrir un formulario específico para consultar movimientos de caja, pero por ahora reutilizo el de movimientos generales
        }
    }
}
