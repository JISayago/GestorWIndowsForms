﻿using AccesoDatos.Entidades;
using Presentacion.FBase;
using Presentacion.FormulariosBase.Helpers;
using Servicios.LogicaNegocio.Articulo.Marca.DTO;
using Servicios.LogicaNegocio.Producto;
using Servicios.LogicaNegocio.Producto.DTO;
using Servicios.LogicaNegocio.Producto.Lote;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion.Core.Producto
{
    public partial class FGestionStockLotes : FBaseABM
    {
        //al crear lo se vuelve a abir el form pero no tiene el numero/nombre del siguiente lote
        private readonly ILoteServicio _loteSevicio;
        private readonly IProductoServicio _productoServicio;

        //borrar si no hacen falta
        TipoOperacion TipoOperacion;
        private ProductoDTO productoDTO;
        private LoteDTO loteDTO;
        private string NumeroLote;
        public bool reabrirForm { get; private set; } = false;
        public bool RealizoOperacion { get; private set; } = false;

        public FGestionStockLotes(TipoOperacion tipoOperacion, long? entidadId = null)
            : base(tipoOperacion, entidadId)
        {
            InitializeComponent();

            _loteSevicio = new LoteServicio();
            _productoServicio = new ProductoServicio();

            TipoOperacion = tipoOperacion;

            dtpFechaVencimiento.Format = DateTimePickerFormat.Short;

            AgregarControlesObligatorios(nudStockInicial, "Stock Inicial");
            AgregarControlesObligatorios(nudStockActual, "Stock Actual");
            AgregarControlesObligatorios(txtNumeroLote, "Numero Lote");
            //AgregarControlesObligatorios(txtDescripcionLote, "Descripcion");
            if (chkFechaVencimiento.Checked)
            {
                AgregarControlesObligatorios(dtpFechaVencimiento, "Fecha Vencimiento");
            }
            //IdProducto = productoDTO.ProductoId,
            //    StockInicial = nudStockInicial.Value,
            //    StockActual = nudStockActual.Value,
            //    NumeroLote = txtNumeroLote.Text,
            //    Descripcion = txtDescripcionLote.Text,
            //    FechaAlta = DateTime.Now, //cambiar por datetime , asi se puede filtrar el mas viejo con la hora incluida
            //    FechaVencimiento = chkFechaVencimiento.Checked ? dtpFechaVencimiento.Value : null,
            //    EstaVencido = false,
            //    EstaActivo = true

            if (tipoOperacion == TipoOperacion.Eliminar)
            {
                DesactivarControles(this);
                chkLoteEstaActivo.Enabled = false;
            }

            if (tipoOperacion == TipoOperacion.Nuevo)
            {
                productoDTO = _productoServicio.ObtenerProductoPorId(entidadId.Value);

                lblNombreProducto.Text = productoDTO.Descripcion.ToString();

                NumeroLote = _loteSevicio.GenerarNumeroLote();

                dtpFechaVencimiento.MinDate = DateTime.Now;

                if (productoDTO.TieneVencimiento)
                {
                    chkFechaVencimiento.Checked = true;
                    chkFechaVencimiento.Enabled = false;
                }
            }
            else
            {
                loteDTO = _loteSevicio.ObtenerLotePorId(entidadId.Value);
                productoDTO = _productoServicio.ObtenerProductoPorId(loteDTO.IdProducto);

                lblNombreProducto.Text = productoDTO.Descripcion.ToString();

                if (productoDTO.TieneVencimiento)
                {
                    chkFechaVencimiento.Checked = true;
                    dtpFechaVencimiento.Value = loteDTO.FechaVencimiento.Value;
                }
                else
                {
                    chkFechaVencimiento.Checked = false;
                    dtpFechaVencimiento.Enabled = false;
                    // Simular NULL
                    dtpFechaVencimiento.Format = DateTimePickerFormat.Custom;
                    dtpFechaVencimiento.CustomFormat = " ";
                }
            }


        }

        #region 🔵 EVENTOS
        private void chkFechaVencimiento_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkFechaVencimiento.Checked)
            {
                dtpFechaVencimiento.Enabled = true;
                dtpFechaVencimiento.Format = DateTimePickerFormat.Short;
                dtpFechaVencimiento.Value = DateTime.Now; // o el valor que quieras
            }
            else
            {
                dtpFechaVencimiento.Enabled = false;

                // Simular NULL
                dtpFechaVencimiento.Format = DateTimePickerFormat.Custom;
                dtpFechaVencimiento.CustomFormat = " ";
            }
        }

        #endregion
        #region 🔵 OVERIDES FBASEABM
        public override void DesactivarControles(object obj)
        {
            base.DesactivarControles(obj);

            btnLimpiar.Enabled = false;
            btnLimpiar.Visible = false;
        }

        public override void CargarDatos(long? entidadId)
        {
            if (!entidadId.HasValue)
            {
                Informar("No se pudo obtener el lote a modificar/eliminar.","Error");
                //MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                this.Close();
            }

            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                btnLimpiar.Enabled = false;
            }

            var lote = _loteSevicio.ObtenerLotePorId(entidadId.Value);

            //CARGAR ESTADOS CHECKBOX CON EL LOTE BUSCADO

            if (lote != null)
            {
                txtNumeroLote.Text = lote.NumeroLote;
                txtDescripcionLote.Text = lote.Descripcion;
                nudStockInicial.Value = lote.StockInicial;
                nudStockActual.Value = lote.StockActual;
                chkLoteEstaActivo.Checked = lote.EstaActivo;

                if (lote.FechaVencimiento.HasValue)
                {
                    chkFechaVencimiento.Checked = true;
                    chkFechaVencimiento.Enabled = false;

                    dtpFechaVencimiento.Value = lote.FechaVencimiento.Value;
                }
                else
                {
                    chkFechaVencimiento.Checked = false;
                    dtpFechaVencimiento.Enabled = false;
                    // Simular NULL
                    dtpFechaVencimiento.Format = DateTimePickerFormat.Custom;
                    dtpFechaVencimiento.CustomFormat = " ";
                }
            }
            else
            {
                Informar("No se pudo obtener el lote a modificar/eliminar.", "Error");
                //MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }

        public override bool EjecutarComandoNuevo()
        {
            if (!VerificarDatosObligatorios()) //no la estoy usando
            {
                Informar("Por favor ingrese los campos Obligatorios.", "Atención");
                //MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                //    MessageBoxIcon.Error);
                return false;
            }

            if (nudStockActual.Value > nudStockInicial.Value)
            {
                Informar("El Stock Actual no puede ser mayor al Stock Inicial.", "Atención");
                //MessageBox.Show(@"El Stock Actual no puede ser mayor al Stock Inicial.", @"Atención", MessageBoxButtons.OK,
                //    MessageBoxIcon.Error);
                return false;
            }

            var loteNuevo = new LoteDTO
            {
                IdProducto = productoDTO.ProductoId,
                StockInicial = nudStockInicial.Value,
                StockActual = nudStockActual.Value,
                NumeroLote = txtNumeroLote.Text,
                Descripcion = txtDescripcionLote.Text,
                FechaAlta = DateTime.Now, //cambiar por datetime , asi se puede filtrar el mas viejo con la hora incluida
                FechaVencimiento = chkFechaVencimiento.Checked ? dtpFechaVencimiento.Value : null,
                EstaVencido = false,
                EstaActivo = true
            };

            var response = _loteSevicio.CrearLote(loteNuevo);

            if (response.Exitoso)
            {
                //_productoServicio.ModificarEstadoStockProductos();
                var result = Confirmar(
                 $"{response.Mensaje}\n ¿Quieres cargar un lote de mismo producto?",
                    "Confirmar acción",
                 si: "Sumar cantidad",
                 no: "Cancelar");

                //var respuesta = MessageBox.Show($"{response.Mensaje}\n ¿Quieres cargar un lote de mismo producto?",
                //    "Confirmar acción",
                //    MessageBoxButtons.YesNo,
                //    MessageBoxIcon.Question);

                if(result)
                {
                    RealizoOperacion = true;
                    reabrirForm = true;
                    this.Close();
                }
                else
                {
                    RealizoOperacion = true; // Indicar que se realizó una operación exitosa
                    this.Close();
                }

                return true;
            }
            else
            {
                MostrarError(response.Mensaje);
                //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                //   MessageBoxIcon.Error);
                return false;
            }
        }

        public override bool EjecutarComandoEliminar()
        {
            if (!EntidadID.HasValue)
            {
                Informar("Por favor seleccione un lote válido.", "Error");
                //MessageBox.Show(@"´Por favor seleccione una marca válida.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                var response = _loteSevicio.EliminarLote((long)EntidadID);
                if (response.Exitoso)
                {
                    //_productoServicio.ModificarEstadoStockProductos();
                    Exito(response.Mensaje,"Atención");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //   MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MostrarError(response.Mensaje);
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //   MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;

        }

        public override bool EjecutarComandoModificar()
        {
            if (!VerificarDatosObligatorios())
            {
                Informar("Por favor ingrese los campos Obligatorios.", "Atención");
                //MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                    //MessageBoxIcon.Error);
                return false;
            }
            if (TipoOperacion == TipoOperacion.Modificar)
            {
                if (!EntidadID.HasValue)
                {
                    Informar("Por favor seleccione un lote válido.", "Error");
                    //MessageBox.Show(@"´Por favor seleccione un marca válida.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;

                }

                var LoteModificar = new LoteDTO
                {
                    NumeroLote = txtNumeroLote.Text,
                    IdProducto = productoDTO.ProductoId,
                    StockInicial = nudStockInicial.Value,
                    StockActual = nudStockActual.Value,
                    Descripcion = txtDescripcionLote.Text,
                    FechaVencimiento = chkFechaVencimiento.Checked ? dtpFechaVencimiento.Value : null,
                    EstaVencido = chkFechaVencimiento.Checked && dtpFechaVencimiento.Value < DateTime.Now, //revisar
                    EstaActivo = chkLoteEstaActivo.Checked
                };
                var response = _loteSevicio.ModficiarLote(LoteModificar, EntidadID.Value);

                if (response.Exitoso)
                {
                    //_productoServicio.ModificarEstadoStockProductos();
                    Exito(response.Mensaje, "Atención");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //    MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MostrarError(response.Mensaje);
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //    MessageBoxIcon.Error);
                    return false;
                }

            }
            return true;

        }

        #endregion

        private void FGestionStockLotes_Load(object sender, EventArgs e)
        {
            if (TipoOperacion == TipoOperacion.Nuevo) //Nombre default auto generado cuando cargar un lote nuevo
            {
                chkLoteEstaActivo.Checked = true;

                txtNumeroLote.Text = NumeroLote;
            }
        }

        private void nudStockInicial_ValueChanged(object sender, EventArgs e)
        {
            // El máximo de Stock Actual ahora es el valor de Stock Inicial
            nudStockInicial.Maximum = 999999;
            nudStockInicial.Minimum = 0;

            nudStockActual.Maximum = nudStockInicial.Value;
            nudStockActual.Minimum = 0;


            // Opcional: Si al bajar el inicial, el actual queda por encima, 
            // el control NumericUpDown lo bajará automáticamente al nuevo máximo.
        }
    }
}
