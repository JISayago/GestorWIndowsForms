﻿using Presentacion.FBase;
using Presentacion.FBase.Helpers;
using Presentacion.FormulariosBase.Helpers;
using Servicios.LogicaNegocio.Empleado;
using Servicios.LogicaNegocio.Empleado.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Model;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Presentacion.Core.Empleado
{
    public partial class FEmpleadoABM : FBaseABM
    {
        private readonly IEmpleadoServicio _empleadoServicio;

        public override void FBaseABM_Load(object sender, EventArgs e)
        {
            base.FBaseABM_Load(sender, e);
            Inicializador(EntidadID);
        }
        public FEmpleadoABM(TipoOperacion tipoOperacion, long? entidadID = null) : base(tipoOperacion, entidadID)
        {
            InitializeComponent();
            _empleadoServicio = new EmpleadoServicio();

            dtpFIngreso.MaxDate = DateTime.Now.AddDays(1);
            dtpFNacimiento.MaxDate = DateTime.Now.AddDays(1);

            if (tipoOperacion == TipoOperacion.Eliminar || tipoOperacion == TipoOperacion.Modificar)
            {
                CargarDatos(entidadID);
            }

            if (tipoOperacion == TipoOperacion.Eliminar)
            {
                DesactivarControles(this);
            }

            AgregarControlesObligatorios(txtNombre, "Nombre");
            AgregarControlesObligatorios(txtApellido, "Apellido");
            AgregarControlesObligatorios(txtDni, "DNI", Validaciones.SoloNumeros, Validaciones.Longitud(7, 8));
            AgregarControlesObligatorios(dtpFIngreso, "Fecha de ingreso", Validaciones.FechaNoFutura);
            AgregarControlesObligatorios(dtpFNacimiento, "Fecha de nacimiento", Validaciones.FechaNoFutura);
            AgregarValidacionOpcional(txtEmail, "Email", Validaciones.Email);
            AgregarValidacionOpcional(txtTelefono, "Teléfono", Validaciones.SoloNumeros,Validaciones.MayorACero);
            AgregarValidacionOpcional(txtCelular, "Celular", Validaciones.SoloNumeros,Validaciones.MayorACero);

        }
        public override void Inicializador(long? entidadId)
        {

        }

        public override void CargarDatos(long? entidadId)
        {
            if (!entidadId.HasValue)
            {
                Informar("Error al cargar los datos del empleado.");
                //MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                this.Close();
            }

            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                btnLimpiar.Enabled = false;
            }

            var empleado = _empleadoServicio.ObtenerEmpleadoPorId(entidadId.Value);

            // Datos Personales
            txtApellido.Text = empleado.Apellido;
            txtNombre.Text = empleado.Nombre;
            txtLegajo.Text = empleado.Legajo;
            txtDireccion.Text = empleado.Direccion;
            txtCelular.Text = empleado.Telefono2;
            txtCuil.Text = empleado.Cuil;
            txtDni.Text = empleado.Dni;
            txtEmail.Text = empleado.Email;
            dtpFNacimiento.Value = (DateTime)empleado.FechaNacimiento;
            txtTelefono.Text = empleado.Telefono;
            dtpFIngreso.Value = empleado.FechaIngreso;
        }


        public override bool EjecutarComandoNuevo()
        {

            if (!VerificarDatosObligatorios())
            {
                Informar("Por favor ingrese los campos Obligatorios.");
                //MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                    //MessageBoxIcon.Error);
                return false;
            }
            if (txtDni.Text.Length > 15)
            {
                Informar("El DNI no puede tener más de 15 caracteres.");
                //MessageBox.Show(@"El DNI no puede tener más de 15 caracteres.", @"Atención", MessageBoxButtons.OK,
                    //MessageBoxIcon.Error);
                return false;
            }
            if(string.IsNullOrEmpty(txtLegajo.Text))
            {
                var result = !Confirmar(
               "El campo Legajo está vacío. ¿Desea que se complete automáticamente con el valor del DNI?", "Confirmación",
                 si: "Sumar cantidad",
                 no: "Cancelar");

                //var respuesta = MessageBox.Show("El campo Legajo está vacío. ¿Desea que se complete automáticamente con el valor del DNI?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(result)
                {
                    txtLegajo.Text = txtDni.Text;
                }
                else
                {
                    return false;
                }
            }
            var nuevoEmpleado = new EmpleadoDTO
            {
                Apellido = txtApellido.Text,
                Nombre = txtNombre.Text,
                Legajo = txtLegajo.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtCelular.Text,
                Cuil = txtCuil.Text,
                Dni = txtDni.Text,
                Email = txtEmail.Text,
                FechaNacimiento = dtpFNacimiento.Value,
                Telefono2 = txtCelular.Text,
                EstaEliminado = false,
                FechaIngreso = dtpFIngreso.Value
            };

            var response = _empleadoServicio.Insertar(nuevoEmpleado);

            if (response.Exitoso)
            {
                Exito("Empleado agregado correctamente.");
                //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                //   MessageBoxIcon.Information);
                return true;
            }
            else
            {
                MostrarError($"{response.Mensaje}");
                //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                //   MessageBoxIcon.Error);
                return false;
            }
        }

        public override bool EjecutarComandoEliminar()
        {
            if (!EntidadID.HasValue)
            {
                Informar("Por favor seleccione un empleado válido.");
                //MessageBox.Show(@"´Por favor seleccione un empleado válido.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                var response = _empleadoServicio.Eliminar((long)EntidadID);
                if (response.Exitoso)
                {
                    Exito($"{response.Mensaje}");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //   MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MostrarError($"{response.Mensaje}");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       //MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;
        }
        public override bool EjecutarComandoModificar()
        {
            if (!EntidadID.HasValue)
            {
                Informar("Por favor seleccione un empleado válido.");
                //MessageBox.Show(@"´Por favor seleccione un empleado válido.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Modificar)
            {

                var empleadoEditar = new EmpleadoDTO
                {
                    Apellido = txtApellido.Text,
                    Nombre = txtNombre.Text,
                    Legajo = txtLegajo.Text,
                    Direccion = txtDireccion.Text,
                    Telefono = txtCelular.Text,
                    Cuil = txtCuil.Text,
                    Dni = txtDni.Text,
                    Email = txtEmail.Text,
                    FechaNacimiento = dtpFNacimiento.Value,
                    Telefono2 = txtCelular.Text,
                    EstaEliminado = false,
                    FechaIngreso = dtpFIngreso.Value
                };

                var response = _empleadoServicio.Modificar(empleadoEditar, EntidadID);

                if (response.Exitoso)
                {
                    Exito($"{response.Mensaje}");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       //MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MostrarError($"{response.Mensaje}");
                    //MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                    //   MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;
        }

    }
}
