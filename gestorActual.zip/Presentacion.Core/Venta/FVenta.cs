﻿using AccesoDatos.Entidades;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Presentacion.AccesoAlSistema;
using Presentacion.Core.Cliente;
using Presentacion.Core.Empleado;
using Presentacion.Core.Oferta;
using Presentacion.Core.Producto;
using Presentacion.Core.Venta.HelpersVenta;
using Presentacion.Core.Venta.HelpersVenta.Servicios.Helpers.Venta;
using Presentacion.FBase.Helpers;
using Presentacion.Formularios;
using Servicios.Helpers.OpcionesPagos;
using Servicios.Helpers.Sistema;
using Servicios.Helpers.Venta.Oferta;
using Servicios.LogicaNegocio.Cliente;
using Servicios.LogicaNegocio.Cliente.DTO;
using Servicios.LogicaNegocio.CuentaCorriente;
using Servicios.LogicaNegocio.Empleado;
using Servicios.LogicaNegocio.Movimiento;
using Servicios.LogicaNegocio.Producto;
using Servicios.LogicaNegocio.Venta;
using Servicios.LogicaNegocio.Venta.DTO;
using Servicios.LogicaNegocio.Venta.Oferta;
using System.ComponentModel;
using System.Globalization;

namespace Presentacion.Core.Venta
{
    public partial class FVenta : FBase.FBase
    {
        private readonly IVentaServicio _ventaServicio;
        private readonly IEmpleadoServicio _empleadoServicio;
        private readonly IOfertaServicio _ofertaServicio;
        private readonly IMovimientoServicio _movimientoServicio;
        private readonly IClienteServicio _clienteServicio;
        private readonly IProductoServicio _productoServicio;


        private long? VENTAID = null;
        private VentaDTO VENTAELIMINAR;
        private long idVendedor = 0;
        private VentaDTO _venta;
        private bool finalizarVenta = false;
        private readonly long _usuarioLogeadoID;
        private UsuarioLogeado _usuarioLogeado;
        private ClienteDTO _clienteVenta;
        private bool esUsuarioLogeado;
        private bool esConsumidorFinal;
        private System.Windows.Forms.Timer timer;
        private decimal _totalVenta = 0.00m;
        private decimal _subTotalVenta = 0.00m;
        private decimal _porcentajeDescuento = 0.00m;
        private string descripcionVenta = "";
        //configuracion tomada del json de config.
        private bool _incluirCtaCte = true;
        private BindingList<ItemVentaDTO> itemsVenta;
        private CuerpoDetalleVenta _cuerpoDetalleVenta;
        private List<FormaPago> tipoDePagosVenta;
        private string detallesExtraDePago = "";
        private bool _actualizandoGrilla = false;
        private bool cargarOferta = false;
        private long idCliente;
        private ClienteDTO consumidorFinal;


        public FVenta(long UsuarioLogeadoId, long? VentaId = null)
        {
            InitializeComponent();

            _ventaServicio = new VentaServicio();
            _movimientoServicio = new MovimientoServicio();
            _usuarioLogeadoID = UsuarioLogeadoId;
            _empleadoServicio = new EmpleadoServicio();
            _ofertaServicio = new OfertaServicio();
            _clienteServicio = new ClienteServicio();
            _productoServicio = new ProductoServicio();

            VENTAID = VentaId;


            //VENTANA FULLSCREEN SIN BORDES NI BOTONES DE CIERRE
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.ShowIcon = false;
            this.ShowInTaskbar = false; // opcional

            if (VentaId != null)
            {
                var ventaCargada = _ventaServicio.ObtenerVentaDetalle((long)VENTAID);

                if (ventaCargada == null)
                {
                    MostrarError("No se pudo cargar la venta.");
                    //MessageBox.Show("No se pudo cargar la venta.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                VENTAELIMINAR = new VentaDTO
                {
                    VentaId = ventaCargada.VentaId,
                    NumeroVenta = ventaCargada.NumeroVenta,
                    IdEmpleado = ventaCargada.IdEmpleado,
                    IdVendedor = ventaCargada.IdVendedor,
                    IdCliente = ventaCargada.IdCliente,
                    FechaVenta = ventaCargada.FechaVenta,
                    Total = ventaCargada.Total,
                    TotalSinDescuento = ventaCargada.TotalSinDescuento,
                    Descuento = ventaCargada.Descuento,
                    Estado = 0, // q pingo hacemo aca
                    Detalle = ventaCargada.Detalle,
                    TiposDePagoSeleccionado = ventaCargada.TiposDePagoSeleccionado
                        .Select(p => new FormaPago
                        {
                            TipoDePago = p.TipoDePago,
                            Monto = p.Monto
                        }).ToList(),
                    Items = ventaCargada.Items
                        .Select(i => new ItemVentaDTO
                        {
                            ItemId = i.ItemId,
                            Cantidad = i.Cantidad,
                            PrecioVenta = i.PrecioVenta,
                            PrecioOferta = i.PrecioOferta,
                            Descripcion = i.Descripcion,
                            EsOferta = i.EsOferta,
                            TipoOferta = i.TipoOferta,
                            CodigoOferta = i.CodigoOferta,

                        }).ToList()
                };
                itemsVenta = new BindingList<ItemVentaDTO>(ventaCargada.Items);

            }
            else
            {

                _cuerpoDetalleVenta = new CuerpoDetalleVenta
                {
                    tiposDePago = new List<FormaPago>(),
                    pagoParcial = false,
                    saldoPendiente = 0.00m,
                    ofertaIncluidas = false,
                    descripcionOferta = ""
                };
                itemsVenta = new BindingList<ItemVentaDTO>();
                consumidorFinal = _clienteServicio.ObtenerConsumidorFinal();
                if (consumidorFinal != null)
                {
                    idCliente = consumidorFinal.PersonaId;

                }

            }
        }

        private void FVenta_Load(object sender, EventArgs e)
        {
            InicializarYLimpiarCampos(VENTAID);
            dgvProductos.CellFormatting += dgvProductos_CellFormatting;
        }

        private void MyTimer_Tick(object sender, EventArgs e)
        {
            var ahora = DateTime.Now;
            var cultura = new CultureInfo("es-ES");

            lblFechaHoy.Text = ahora.ToString("dd/MM/yyyy");
            lblHoraMinutos.Text = ahora.ToString("HH:mm:ss");
            lblDiaAbrev.Text = cultura.TextInfo.ToTitleCase(ahora.ToString("ddd", cultura)) + ".";

        }

        private void ActualizarCamposInicio(long? ventaId)
        {
            if (ventaId != null)
            {
                var vendedor = _empleadoServicio.ObtenerEmpleadoPorId(VENTAELIMINAR.IdVendedor);
                txtCliente.Text = _clienteVenta != null ? $"{_clienteVenta.Nombre} {_clienteVenta.Apellido}" : consumidorFinal.NombreCompleto;
                lblVendedorAsignado.Text = $"{vendedor.Nombre} {vendedor.Apellido}";
            }
            else
            {
                txtCliente.Text = _clienteVenta != null ? $"{_clienteVenta.Nombre} {_clienteVenta.Apellido}" : consumidorFinal != null ? consumidorFinal.NombreCompleto : "";
                lblVendedorAsignado.Text = esUsuarioLogeado
                    ? $"{_usuarioLogeado.Nombre} {_usuarioLogeado.Apellido}"
                    : "";
            }
            if (esConsumidorFinal)
            {
                cbxIncluirCtaCte.Checked = false;
                cbxIncluirCtaCte.Enabled = false;
            }
            if (_usuarioLogeado != null)
            {
                lblVendedorAsignado.Text = $"{_usuarioLogeado.Nombre} {_usuarioLogeado.Apellido}";
            }
        }


        private void cbxUsuarioLogeado_CheckedChanged(object sender, EventArgs e)
        {
            esUsuarioLogeado = !esUsuarioLogeado;
            ActualizarCamposInicio(VENTAID);
            btnCambiarVendedor.Enabled = !esUsuarioLogeado;
        }

        private void cbxConsumidorFinal_CheckedChanged(object sender, EventArgs e)
        {
            esConsumidorFinal = cbxConsumidorFinal.Checked;
            if (cbxConsumidorFinal.Checked)
            {
                _clienteVenta = consumidorFinal;
            }
            btnCargarCliente.Enabled = !esConsumidorFinal;
            ActualizarCamposInicio(VENTAID);
        }
        private void btnConfirmarYFPago_Click(object sender, EventArgs e)
        {
            if (_totalVenta == 0)
            {
                MostrarError("Debe cargar al menos un producto antes de confirmar la venta.");
                //MessageBox.Show("Debe cargar al menos un producto antes de confirmar la venta.");
                return;
            }

            if (!DatosSistema.CajaId.HasValue)
            {
                MostrarError("No hay una caja abierta. No se puede registrar la venta.");
                //MessageBox.Show("No hay una caja abierta. No se puede registrar la venta.");
                return;
            }

            // Si ya se confirmó antes, registrar la venta directamente
            if (finalizarVenta)
            {
                FinalizacionVenta();
                return;
            }

            DatosVenta datosVenta = new DatosVenta
            {
                Total = _totalVenta,
                IncluirCtaCte = _incluirCtaCte,
                DescuentoEfectivo = cbxDescEfectivo.Checked,
                Cliente = _clienteVenta
            };

            var fSeleccionCantidad = new FSeleccionCantidadPagos();

            if (fSeleccionCantidad.ShowDialog() != DialogResult.OK)
                return;

            bool esMultiples = fSeleccionCantidad.multiplePagos;
            int cantidadPagos = fSeleccionCantidad.CantidadPagos;

            // =========================
            // 🔥 MULTIPLES PAGOS
            // =========================
            if (esMultiples)
            {
                using var fPagoMultiple = new FPagoMultiple(cantidadPagos, _totalVenta, datosVenta, idCliente);

                if (fPagoMultiple.ShowDialog() != DialogResult.OK)
                    return;

                var pagosSeleccionados = fPagoMultiple.ResultPagos;

                if (pagosSeleccionados == null || pagosSeleccionados.Count == 0)
                {
                    Advertir("Debe ingresar al menos un pago válido.");
                    //MessageBox.Show("Debe ingresar al menos un pago válido.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                tipoDePagosVenta = pagosSeleccionados;

                _cuerpoDetalleVenta.tiposDePago = pagosSeleccionados;

                _cuerpoDetalleVenta.TotalOriginal = _subTotalVenta;
                _cuerpoDetalleVenta.TotalFinal = _totalVenta;

                var suma = pagosSeleccionados.Sum(p => p.Monto);
                _cuerpoDetalleVenta.saldoPendiente = _totalVenta - suma;
                _cuerpoDetalleVenta.pagoParcial = _cuerpoDetalleVenta.saldoPendiente > 0m;


                // 🔥 CLAVE: cargar ofertas ANTES
                CargarInfoOfertas();

                txtAreaDetallesVenta.Text = _cuerpoDetalleVenta.CuerpoDelTextoTP();

                GenerarDetalleVenta(tipoDePagosVenta);
                return;
            }

            // =========================
            // 🔥 UN SOLO PAGO
            // =========================
            var fConfirmarVenta = new FConfirmacionVenta(datosVenta, idCliente)
            {
                PermitirMultiplesPagos = false
            };

            if (fConfirmarVenta.ShowDialog() == DialogResult.OK)
            {
                var tipoPagosSeleccionados = fConfirmarVenta.pagos;

                if (tipoPagosSeleccionados == null || tipoPagosSeleccionados.Count == 0)
                {
                    Advertir("Debe seleccionar al menos un tipo de pago.");
                    //MessageBox.Show("Debe seleccionar al menos un tipo de pago.");
                    return;
                }

                tipoDePagosVenta = tipoPagosSeleccionados;
                _cuerpoDetalleVenta.tiposDePago = tipoPagosSeleccionados;
                _cuerpoDetalleVenta.TotalOriginal = _subTotalVenta;
                _cuerpoDetalleVenta.TotalFinal = _totalVenta;
                _cuerpoDetalleVenta.saldoPendiente = fConfirmarVenta.MontoPendiente;
                _cuerpoDetalleVenta.pagoParcial = fConfirmarVenta.MontoPendiente > 0.00m;
                //detallesExtraDePago = fConfirmarVenta.datosExtraPagos;

                // 🔥 CLAVE: cargar ofertas ANTES
                CargarInfoOfertas();

                txtAreaDetallesVenta.Text = _cuerpoDetalleVenta.CuerpoDelTextoTP();

                GenerarDetalleVenta(tipoPagosSeleccionados);
            }
        }
        private void CargarInfoOfertas()
        {
            var ofertas = itemsVenta
                .Where(x => x.EsOferta)
                .ToList();

            if (!ofertas.Any())
            {
                _cuerpoDetalleVenta.ofertaIncluidas = false;
                _cuerpoDetalleVenta.descripcionOferta = string.Empty;
                return;
            }

            _cuerpoDetalleVenta.ofertaIncluidas = true;

            var descripciones = ofertas
                .Select(o =>
                {
                    var tipo = o.TipoOferta switch
                    {
                        (int)Servicios.Helpers.Venta.Oferta.TipoOferta.Producto => "Producto",
                        (int)Servicios.Helpers.Venta.Oferta.TipoOferta.Grupo => "Descuento",
                        (int)Servicios.Helpers.Venta.Oferta.TipoOferta.Combo => "Combo",
                        (int)Servicios.Helpers.Venta.Oferta.TipoOferta.DosPorUno => "2x1",
                        _ => "Oferta"
                    };

                    return $"{tipo}: {o.Descripcion}";
                })
                .Distinct()
                .ToList();

            _cuerpoDetalleVenta.descripcionOferta = string.Join(", ", descripciones);
        }
        private async Task FinalizacionVenta()
        {
            if (!finalizarVenta)
                return;

            using var frmProcesando = new FProcesando();

            frmProcesando.Show();
            frmProcesando.ActualizarEstado("Generando venta...");

            try
            {
                this.Enabled = false;

                _venta = new VentaDTO
                {
                    NumeroVenta = lblNro.Text,
                    IdEmpleado = _usuarioLogeadoID,
                    IdVendedor = idVendedor,
                    IdCliente = VENTAID != null
                        ? (long?)idCliente
                        : _clienteVenta.PersonaId,

                    FechaVenta = DateTime.Now,
                    Total = _totalVenta,
                    TotalSinDescuento = _subTotalVenta,
                    Descuento = _porcentajeDescuento,
                    Detalle = _cuerpoDetalleVenta.CuerpoDelTextoFinal(descripcionVenta),
                    Items = itemsVenta.ToList(),
                    TiposDePagoSeleccionado = tipoDePagosVenta
                };

                frmProcesando.ActualizarEstado("Registrando venta...");

                var m = await Task.Run(() =>
                    _ventaServicio.NuevaVenta(_venta));

                frmProcesando.Close();

                if (m.Exitoso)
                {
                    Exito("Venta confirmada exitosamente.");
                    //MessageBox.Show(
                    //    "Venta confirmada exitosamente.",
                    //    "Éxito",
                    //    MessageBoxButtons.OK,
                    //    MessageBoxIcon.Information);

                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MostrarError($"Hubo un error al finalizar la venta: {m.Mensaje}");
                    //MessageBox.Show(
                    //    $"Hubo un error al finalizar la venta: {m.Mensaje}",
                    //    "Error",
                    //    MessageBoxButtons.OK,
                    //MessageBoxIcon.Error);
                }
            }
            finally
            {
                this.Enabled = true;
            }
        }

        private void GenerarDetalleVenta(List<FormaPago> tipoPagosSeleccionados)
        {
            if (tipoPagosSeleccionados.Count > 0)
            {
                var fConfirmarDetalle = new FDetalleVenta();

                if (fConfirmarDetalle.ShowDialog() == DialogResult.OK)
                {
                    if (fConfirmarDetalle.confirmarDetalle)
                    {
                        btnConfirmarYFPago.Text = "Finalizar";
                        finalizarVenta = true;
                    }

                    if (!string.IsNullOrWhiteSpace(fConfirmarDetalle.descripcionDetalle))
                    {
                        descripcionVenta = fConfirmarDetalle.descripcionDetalle.Trim();
                    }
                    else
                    {
                        descripcionVenta = "Sin detalles adicionales.";
                    }

                    // 🔥 ACÁ ya incluye pagos + saldo + ofertas + extra
                    txtAreaDetallesVenta.Text =
                        _cuerpoDetalleVenta.CuerpoDelTextoFinal(descripcionVenta);
                }
            }
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbxIncluirCtaCte_CheckedChanged(object sender, EventArgs e)
        {
            _incluirCtaCte = cbxIncluirCtaCte.Checked;
            ActualizarCamposInicio(VENTAID);
        }

        private void btnCargarProducto_Click(object sender, EventArgs e)
        {
            var fProductos = new FProductoConsulta(true);

            if (fProductos.ShowDialog() != DialogResult.OK ||
                !fProductos.productoSeleccionado.HasValue)
                return;

            var itemVenta = _productoServicio.ObtenerItemVenta(
                fProductos.productoSeleccionado.Value);

            if (itemVenta == null)
            {
                Advertir("El producto seleccionado no está disponible.");
                //MessageBox.Show("El producto seleccionado no está disponible.");
                return;
            }

            var fCantidad = new FCantidadItem("2");

            if (fCantidad.ShowDialog() != DialogResult.OK ||
                fCantidad.cantidad <= 0)
                return;

            var cantidadSolicitada = fCantidad.cantidad;

            // Buscar si el mismo item ya fue agregado
            var itemExistente = itemsVenta
                .FirstOrDefault(x => EsMismoItem(x, itemVenta));

            if (itemExistente != null)
            {


                if (!Confirmar(
                    $"'{itemVenta.Descripcion}' ya fue agregado.\n\n" +
                    "¿Desea sumar la cantidad ingresada a la existente?",
                    "Elemento repetido",
                    si: "Sumar cantidad",
                    no: "Cancelar"))
                    return;

                var nuevaCantidad = itemExistente.Cantidad + cantidadSolicitada;

                if (nuevaCantidad > itemVenta.Stock)
                {
                    Advertir(
                        $"No hay stock suficiente.\n" +
                        $"Stock disponible: {itemVenta.Stock}.\n" +
                        $"La cantidad será ajustada al máximo disponible.",
                        "Stock insuficiente");
                    //MessageBox.Show(
                    //    $"No hay stock suficiente.\n" +
                    //    $"Stock disponible: {itemVenta.Stock}.\n" +
                    //    $"La cantidad será ajustada al máximo disponible.",
                    ////    "Stock insuficiente",
                    //    MessageBoxButtons.OK,
                    //    MessageBoxIcon.Warning);

                    nuevaCantidad = itemVenta.Stock;
                }

                itemExistente.Cantidad = nuevaCantidad;
            }
            else
            {
                if (cantidadSolicitada > itemVenta.Stock)
                {
                    Advertir(
                        $"Stock insuficiente. Se ajusta a {itemVenta.Stock}.",
                        "Advertencia");
                    //MessageBox.Show(
                    //    $"Stock insuficiente. Se ajusta a {itemVenta.Stock}.",
                    //    "Advertencia",
                    //    MessageBoxButtons.OK,
                    //    MessageBoxIcon.Warning);

                    cantidadSolicitada = itemVenta.Stock;
                }

                itemVenta.Cantidad = cantidadSolicitada;

                itemsVenta.Add(itemVenta);
            }

            dgvProductos.Refresh();

            ValidarCantidadySiEsOferta();

            if (cbxDescEfectivo.Checked)
                AplicarDescuentoEfectivo();
            else
                CalcularTotal();
        }
        private bool EsMismoItem(ItemVentaDTO actual, ItemVentaDTO nuevo)
        {
            // Producto normal
            if (!actual.EsOferta && !nuevo.EsOferta)
                return actual.ItemId == nuevo.ItemId;

            // Oferta por grupo (ItemId = ProductoId)
            if (actual.EsOferta && nuevo.EsOferta &&
                actual.TipoOferta == (int)TipoOferta.Grupo &&
                nuevo.TipoOferta == (int)TipoOferta.Grupo)
            {
                return actual.ItemId == nuevo.ItemId;
            }

            // Combo / 2x1 (ItemId = OfertaId)
            if (actual.EsOferta && nuevo.EsOferta &&
                (actual.TipoOferta == (int)TipoOferta.Combo ||
                 actual.TipoOferta == (int)TipoOferta.DosPorUno) &&
                (nuevo.TipoOferta == (int)TipoOferta.Combo ||
                 nuevo.TipoOferta == (int)TipoOferta.DosPorUno))
            {
                return actual.ItemId == nuevo.ItemId;
            }

            return false;
        }
        private void CalcularTotal()
        {
            decimal totalFinal = 0m;
            decimal totalSinDescuento = 0m;

            if (itemsVenta != null && itemsVenta.Any())
            {
                foreach (var item in itemsVenta)
                {
                    // 🔹 Siempre calculás el original
                    var subtotalOriginal = item.PrecioVenta * item.Cantidad;
                    totalSinDescuento += subtotalOriginal;

                    decimal subtotalFinal;

                    if (item.EsOferta)
                    {
                        // 🔥 OFERTA
                        subtotalFinal = item.PrecioOferta * item.Cantidad;
                    }
                    else
                    {
                        // 🔹 PRODUCTO NORMAL
                        subtotalFinal = item.PrecioVenta * item.Cantidad;
                    }

                    totalFinal += subtotalFinal;
                }
            }

            _subTotalVenta = totalSinDescuento;
            _totalVenta = totalFinal;

            txtSubtotalSinDescuento.Text = totalSinDescuento.ToString("C2");
            txtTotal.Text = totalFinal.ToString("C2");
        }

        private void ActualizarGrillas()
        {
            dgvProductos.Refresh(); // refresca la visualización
        }



        public virtual void IniciarGrilla(DataGridView grilla)
        {
            for (int i = 0; i < grilla.ColumnCount; i++)
            {
                grilla.Columns[i].Visible = false;
            }
        }

        private void ResetearGrilla(DataGridView grilla)
        {
            grilla.DataSource = null;

            grilla.Columns.Clear();

            grilla.AutoGenerateColumns = false;

            // 🔒 ID interno (oculto)
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ItemId",
                DataPropertyName = "ItemId",
                Visible = false
            });

            // 📦 Producto
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Descripcion",
                HeaderText = "Producto",
                DataPropertyName = "Descripcion",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            // 🔖 Estado oferta (string en el DTO)
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "CodigoOferta",
                HeaderText = "Codigo Oferta",
                DataPropertyName = "CodigoOferta",
                Width = 180
            });

            // 📏 Medida
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Medida",
                HeaderText = "Medida",
                DataPropertyName = "Medida",
                Width = 100
            });

            // 📐 Unidad de medida
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "UnidadMedida",
                HeaderText = "Unidad",
                DataPropertyName = "UnidadMedida",
                Width = 120
            });

            // 🔢 Cantidad
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Cantidad",
                HeaderText = "Cantidad",
                DataPropertyName = "Cantidad",
                Width = 120
            });

            // 💲 Precio normal
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PrecioVenta",
                HeaderText = "Precio",
                DataPropertyName = "PrecioVenta",
                Width = 150,
                DefaultCellStyle = { Format = "C2" }
            });

            // 🔥 Precio oferta
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PrecioOferta",
                HeaderText = "Precio Oferta",
                DataPropertyName = "PrecioOferta",
                Width = 150,
                DefaultCellStyle = { Format = "C2" }
            });
            grilla.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Subtotal",
                HeaderText = "Subtotal",
                DataPropertyName = "Subtotal",
                Width = 150,
                DefaultCellStyle = { Format = "C2" }
            });


            if (!VENTAID.HasValue)
            {

                // ✏️ Botón editar
                grilla.Columns.Add(new DataGridViewButtonColumn
                {
                    Name = "BtnEditar",
                    HeaderText = "Editar",
                    Text = "✏ Editar",
                    UseColumnTextForButtonValue = true,
                    Width = 130
                });

                // 🗑 Botón eliminar
                grilla.Columns.Add(new DataGridViewButtonColumn
                {
                    Name = "BtnEliminar",
                    HeaderText = "Eliminar",
                    Text = "🗑 Eliminar",
                    UseColumnTextForButtonValue = true,
                    Width = 130
                });
            }
        }


        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (_actualizandoGrilla) return;
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            var fila = dgvProductos.Rows[e.RowIndex];
            if (fila == null || fila.IsNewRow) return;

            // Aquí tu código seguro para manejar el click
        }

        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (_actualizandoGrilla) return;
            if (dgvProductos.CurrentRow == null) return;
            if (dgvProductos.CurrentRow.IsNewRow) return;

            if (!dgvProductos.Columns.Contains("ItemId")) return;

            var val = dgvProductos.CurrentRow.Cells["ItemId"].Value;
            if (val == null || val == DBNull.Value) return;

            // Lógica segura con val
        }

        private void dgvProductos_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (_actualizandoGrilla) return;

            if (e.RowIndex < 0 || e.RowIndex >= dgvProductos.Rows.Count)
                return;

            var fila = dgvProductos.Rows[e.RowIndex];
            if (fila == null || fila.IsNewRow)
                return;

            if (!dgvProductos.Columns.Contains("ItemId"))
                return;

            var celda = fila.Cells["ItemId"];
            if (celda?.Value == null || celda.Value == DBNull.Value)
                return;

            long entidadID = Convert.ToInt64(celda.Value);
        }

        /*private void cbxEnOferta_CheckedChanged(object sender, EventArgs e)
        {
            cargarOferta = cbxEnOferta.Checked;
            btnCargarProducto.Text = cargarOferta ? "Cargar Oferta" : "Cargar Producto";
        }*/

        private void btnCargarCliente_Click(object sender, EventArgs e)
        {
            var cliente = new FClienteConsulta(true);
            if (cliente.ShowDialog() == DialogResult.OK && cliente.clienteSeleccionado.HasValue)
            {
                idCliente = cliente.clienteSeleccionado.Value;
                var _clienteCargado = new ClienteServicio().ObtenerClientePorId(idCliente);
                _clienteVenta = new ClienteDTO
                {
                    PersonaId = _clienteCargado.PersonaId,
                    Nombre = _clienteCargado.Nombre,
                    Apellido = _clienteCargado.Apellido,
                    Dni = _clienteCargado.Dni,
                    NumeroCliente = _clienteCargado.NumeroCliente,
                };
                cbxIncluirCtaCte.Enabled = true;
                cbxIncluirCtaCte.Checked = true;
            }
        }

        private async void btnLimpiar_Click(object sender, EventArgs e)
        {
            if (VENTAID != null)
            {
                var result = !Confirmar(
                  "¿Está seguro que desea cancelar esta venta?\n\nEsta acción no se puede deshacer.", "Confirmar cancelación",
                  si: "Sumar cantidad",
                  no: "Cancelar");
                    
                //var result = MessageBox.Show(
                //    "¿Está seguro que desea cancelar esta venta?\n\nEsta acción no se puede deshacer.",
                //    "Confirmar cancelación",
                //    MessageBoxButtons.OKCancel,
                //    MessageBoxIcon.Warning
                //);

                if (result)
                {
                    using var frmProcesando = new FProcesando();
                    frmProcesando.Show();
                    frmProcesando.ActualizarEstado("Cancelando venta...");

                    var respuesta = await Task.Run(() => CancelarVenta(VENTAID));

                    frmProcesando.Close();

                    if (respuesta.Exitoso)
                    {
                        Confirmar("Venta cancelada con éxito.");
                        //MessageBox.Show("Venta cancelada con éxito.");
                        this.Close();
                    }
                    else
                    {
                        MostrarError(respuesta.Mensaje);
                        //MessageBox.Show(respuesta.Mensaje);
                    }
                }
            }
            else
            {
                finalizarVenta = false;
                InicializarYLimpiarCampos(VENTAID);
            }
        }

        private EstadoOperacion CancelarVenta(long? VenId)
        {
            var respuesta = _ventaServicio.CancelacionVentaPorId((long)VenId);
            return respuesta;
        }

        private void InicializarYLimpiarCampos(long? ventaId)
        {
            if (ventaId != null)
            {
                itemsVenta = new BindingList<ItemVentaDTO>(VENTAELIMINAR.Items);
                ResetearGrilla(dgvProductos);
                dgvProductos.DataSource = itemsVenta;
                var usuarioLogeado = _empleadoServicio.ObtenerEmpleadoPorId(VENTAELIMINAR.IdEmpleado);
                if (VENTAELIMINAR.IdCliente != null)
                {
                    var cid = (long)VENTAELIMINAR.IdCliente;
                    var clienteVenta = _clienteServicio.ObtenerClientePorId(cid);
                    _clienteVenta = new ClienteDTO
                    {
                        Nombre = clienteVenta.Nombre,
                        Apellido = clienteVenta.Apellido
                    };

                }
                _usuarioLogeado = new UsuarioLogeado
                {
                    PersonaId = usuarioLogeado.PersonaId,
                    Username = usuarioLogeado.Username,
                    Nombre = usuarioLogeado.Nombre,
                    Apellido = usuarioLogeado.Apellido,
                };
                //cbxConsumidorFinal.Checked = true;
                //esConsumidorFinal = true;
                //esUsuarioLogeado = true;
                idVendedor = VENTAELIMINAR.IdVendedor; // Asignamos el ID del usuario logueado como vendedor por defecto
                //ResetearGrilla(dgvProductos);
                ActualizarCamposInicio(VENTAID);
                txtTotal.Text = VENTAELIMINAR.Total.ToString("C2");
                txtSubtotalSinDescuento.Text = VENTAELIMINAR.TotalSinDescuento.ToString("C2");
                txtDescuentoEfectivo.Text = VENTAELIMINAR.TotalSinDescuento.ToString("C2");
                lblNro.Text = VENTAELIMINAR.NumeroVenta;
                txtAreaDetallesVenta.Text = VENTAELIMINAR.Detalle;
                //cbxIncluirCtaCte.Checked = true;
                dgvProductos.AllowUserToAddRows = false;
                //cbxDescEfectivo.Checked = false;
                cbxIncluirCtaCte.Checked = false;
                cbxIncluirCtaCte.Enabled = false;
                lblFechaHoy.Text = VENTAELIMINAR.FechaVenta.ToString("dd/MM/yyyy");
                lblDiaAbrev.Text = (VENTAELIMINAR.FechaVenta.ToString("ddd")).ToUpper() + ".";
                lblHoraMinutos.Text = VENTAELIMINAR.FechaVenta.ToString("HH:mm:ss");
                btnLimpiar.Text = "Contrasiento";
                if (VENTAELIMINAR.IdCliente != null)
                {
                    txtCliente.Text = $"{_clienteVenta.Nombre} {_clienteVenta.Apellido}";

                }
                dgvProductos.Enabled = false;
                btnConfirmarYFPago.Enabled = false;
                btnConfirmarYFPago.Visible = false;
                txtAreaDetallesVenta.Enabled = false;
                txtSubtotalSinDescuento.Enabled = false;
                txtTotal.Enabled = false;
                cbxConsumidorFinal.Enabled = false;
                cbxConsumidorFinal.Visible = false;
                cbxDescEfectivo.Enabled = false;
                cbxDescEfectivo.Visible = false;
                btnCargarCliente.Enabled = false;
                btnCargarCliente.Text = "Cliente";
                //btnCargarCliente.Visible = false;
                btnCargarOferta.Enabled = false;
                btnCargarOferta.Visible = false;
                btnCargarProducto.Enabled = false;
                btnCargarProducto.Visible = false;
                btnCambiarVendedor.Enabled = false;
                btnCambiarVendedor.Visible = false;

            }
            else
            {
                var clienteDefault = _clienteServicio.ObtenerConsumidorFinal();
                _clienteVenta = new ClienteDTO
                {
                    PersonaId = clienteDefault.PersonaId,
                    Nombre = clienteDefault.Nombre,
                    Apellido = clienteDefault.Apellido
                };
                itemsVenta = new BindingList<ItemVentaDTO>();

                ResetearGrilla(dgvProductos);

                dgvProductos.DataSource = itemsVenta;
                //ResetearGrilla(dgvProductos);
                ActualizarCamposInicio(VENTAID);
                CalcularTotal();
                //_ventaServicio.GenerateNextNumeroVenta();
                //lblNro.Text = _ventaServicio.GenerateNextNumeroVenta().ToString();
                lblNro.Text = "(Pendiente)";
                System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer();
                MyTimer.Interval = 1000;
                MyTimer.Tick += new EventHandler(MyTimer_Tick);
                MyTimer.Start();
                var usuarioLogeado = _empleadoServicio.ObtenerEmpleadoPorId(_usuarioLogeadoID);
                _usuarioLogeado = new UsuarioLogeado
                {
                    PersonaId = usuarioLogeado.PersonaId,
                    Username = usuarioLogeado.Username,
                    Nombre = usuarioLogeado.Nombre,
                    Apellido = usuarioLogeado.Apellido,
                };
                txtDescuentoEfectivo.Text = string.Empty;
                cbxConsumidorFinal.Checked = true;
                esConsumidorFinal = true;
                esUsuarioLogeado = true;
                idVendedor = _usuarioLogeadoID; // Asignamos el ID del usuario logueado como vendedor por defecto
                btnCargarCliente.Enabled = false;
                cbxIncluirCtaCte.Checked = true;
                dgvProductos.AllowUserToAddRows = false;
                cbxDescEfectivo.Checked = false;
                txtSubtotalSinDescuento.Text = _subTotalVenta.ToString("C2");
                txtTotal.Text = _totalVenta.ToString("C2");
                txtAreaDetallesVenta.Text = string.Empty;
                if (idCliente < 0)
                {
                    cbxIncluirCtaCte.Checked = false;
                    cbxIncluirCtaCte.Enabled = false;
                }
            }
        }

        private bool _suspendCbxDesc = false;

        private void cbxDescEfectivo_CheckedChanged(object sender, EventArgs e)
        {
            if (_suspendCbxDesc) return;

            ValidarCantidadySiEsOferta();

            txtDescuentoEfectivo.Enabled = cbxDescEfectivo.Checked;

            if (!cbxDescEfectivo.Checked)
            {
                txtDescuentoEfectivo.Text = string.Empty;
                CalcularTotal();
            }
        }
        private void ValidarCantidadySiEsOferta()
        {
            if (itemsVenta.Count < 1)
            {
                _suspendCbxDesc = true;
                cbxDescEfectivo.Checked = false;               // no volverá a ejecutar la lógica porque la bandera lo evita
                _suspendCbxDesc = false;
                Advertir("Debe cargar al menos un producto para aplicar un descuento.");
                //MessageBox.Show("Debe cargar al menos un producto para aplicar un descuento.");
                return;
            }

            if (itemsVenta.Any(iv => iv.EsOferta))
            {
                _suspendCbxDesc = true;
                cbxDescEfectivo.Checked = false;
                cbxDescEfectivo.Enabled = false;
                txtDescuentoEfectivo.Text = string.Empty;
                txtDescuentoEfectivo.Enabled = false;
                _suspendCbxDesc = false;

                Advertir("No se puede aplicar descuento por efectivo cuando hay ofertas en la venta.");
                //MessageBox.Show("No se puede aplicar descuento por efectivo cuando hay ofertas en la venta.");
                return;
            }
            else
            {
                cbxDescEfectivo.Enabled = true;
            }
        }

        private void txtDescuentoEfectivo_TextChanged(object sender, EventArgs e)
        {

            AplicarDescuentoEfectivo();
        }
        private void AplicarDescuentoEfectivo()
        {
            if (!decimal.TryParse(txtDescuentoEfectivo.Text, out decimal porcentajeDesc))
                return;

            if (porcentajeDesc < 0 || porcentajeDesc > 100)
            {
                Advertir("Ingresar un número entre 1 y 100.");
                //MessageBox.Show("Ingresar un número entre 1 y 100.");
                if (porcentajeDesc > 100)
                {
                    txtDescuentoEfectivo.Text = "100";
                    porcentajeDesc = 100;
                }
                else
                {
                    txtDescuentoEfectivo.Text = "0";
                    porcentajeDesc = 0;
                }
                return;
            }

            // 🔹 total de productos SIN oferta
            decimal totalSinOferta = itemsVenta
                .Where(i => !i.EsOferta)
                .Sum(i => i.PrecioVenta * i.Cantidad);

            // 🔹 total de productos CON oferta (no se toca)
            decimal totalConOferta = itemsVenta
                .Where(i => i.EsOferta)
                .Sum(i => i.Subtotal);

            // 🔥 descuento solo sobre los que NO tienen oferta
            decimal descuento = totalSinOferta * (porcentajeDesc / 100m);

            decimal totalFinal = totalConOferta + (totalSinOferta - descuento);

            _totalVenta = totalFinal;

            txtTotal.Text = totalFinal.ToString("C2");
        }

        private void btnCambiarVendedor_Click(object sender, EventArgs e)
        {
            var fEmpleado = new FEmpleadoConsulta(true);

            if (fEmpleado.ShowDialog() == DialogResult.OK && fEmpleado.empleadoSeleccionado.HasValue)
            {
                var idEmpleado = fEmpleado.empleadoSeleccionado.Value;

                var vendedor = new EmpleadoServicio().ObtenerEmpleadoPorId(idEmpleado);
                idVendedor = vendedor.PersonaId;

                lblVendedorAsignado.Text = $"{vendedor.Nombre} {vendedor.Apellido}";

            }
        }

        private void btnCargarOferta_Click(object sender, EventArgs e)
        {
            var fOfertas = new FOfertaConsulta(true);

            if (fOfertas.ShowDialog() != DialogResult.OK ||
                !fOfertas.ofertaSeleccionada.HasValue)
                return;

            var itemVenta = _ofertaServicio.ObtenerItemVentaOferta(
                fOfertas.ofertaSeleccionada.Value);

            if (itemVenta == null)
            {
                Advertir("La oferta seleccionada ya no se encuentra activa.");
                //MessageBox.Show("La oferta seleccionada ya no se encuentra activa.");
                return;
            }

            var fCantidad = new FCantidadItem();

            if (fCantidad.ShowDialog() != DialogResult.OK ||
                fCantidad.cantidad <= 0)
                return;

            var cantidadSolicitada = fCantidad.cantidad;

            // Buscar si la oferta ya fue agregada
            var ofertaExistente = itemsVenta.FirstOrDefault(x =>
             x.EsOferta &&
             x.TipoOferta == itemVenta.TipoOferta &&
             x.ItemId == itemVenta.ItemId);

            if (ofertaExistente != null)
            {
                if (!Confirmar($"La oferta '{itemVenta.Descripcion}' ya fue agregada.\n\n" +
                    "¿Desea sumar la cantidad ingresada a la existente?", "Oferta repetida",
                    si: "Sumar cantidad",
                    no: "Cancelar"))
                    return;
                //var respuesta = MessageBox.Show(
                //    $"La oferta '{itemVenta.Descripcion}' ya fue agregada.\n\n" +
                //    "¿Desea sumar la cantidad ingresada a la existente?",
                //    "Oferta repetida",
                //    MessageBoxButtons.YesNo,
                //    MessageBoxIcon.Question);

                //if (respuesta == DialogResult.No)
                //    return;

                var nuevaCantidad = ofertaExistente.Cantidad + cantidadSolicitada;

                //if (nuevaCantidad > itemVenta.Stock)
                //{
                //    MessageBox.Show(
                //        $"No hay stock suficiente.\n" +
                //        $"Stock disponible: {itemVenta.Stock}.\n" +
                //        $"La cantidad será ajustada al máximo disponible.",
                //        "Stock insuficiente",
                //        MessageBoxButtons.OK,
                //        MessageBoxIcon.Warning);

                //    nuevaCantidad = itemVenta.Stock;
                //}

                ofertaExistente.Cantidad = nuevaCantidad;
            }
            else
            {
                //if (cantidadSolicitada > itemVenta.Stock)
                //{
                //    MessageBox.Show(
                //        $"Stock insuficiente. Se ajusta a {itemVenta.Stock}.",
                //        "Advertencia",
                //        MessageBoxButtons.OK,
                //        MessageBoxIcon.Warning);

                //    cantidadSolicitada = itemVenta.Stock;
                //}

                itemVenta.Cantidad = cantidadSolicitada;

                itemsVenta.Add(itemVenta);
            }

            dgvProductos.Refresh();

            ValidarCantidadySiEsOferta();

            if (cbxDescEfectivo.Checked)
                AplicarDescuentoEfectivo();
            else
                CalcularTotal();
        }
        private void dgvProductos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var grilla = (DataGridView)sender;

            if (grilla.Columns[e.ColumnIndex].Name == "EsOferta" && e.Value != null)
            {
                bool esOferta;

                if (e.Value is bool b)
                {
                    esOferta = b;
                }
                else if (e.Value is string s)
                {
                    esOferta = s.Equals("true", StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    return;
                }

                e.Value = esOferta ? "En Oferta Activa" : "Sin Oferta Activa";
                e.FormattingApplied = true;
            }

        }

        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            var grilla = (DataGridView)sender;
            var item = (ItemVentaDTO)grilla.Rows[e.RowIndex].DataBoundItem;

            if (grilla.Columns[e.ColumnIndex].Name == "BtnEliminar")
            {
                EliminarItem(item);
            }
            else if (grilla.Columns[e.ColumnIndex].Name == "BtnEditar")
            {
                EditarCantidad(item);
            }
        }
        private void EliminarItem(ItemVentaDTO item)
        {
            var confirm = !Confirmar(
                 $"¿Está seguro que desea Eliminar {item.Descripcion}?", "Confirmar cancelación",
                 si: "Eliminar",
                 no: "Cancelar");

            //var confirm = MessageBox.Show(
            //    $"¿Eliminar {item.Descripcion}?",
            //    "Confirmar",
            //    MessageBoxButtons.YesNo,
            //    MessageBoxIcon.Question
            //);

            if (confirm)
            {
                itemsVenta.Remove(item);   // lista bindada
                dgvProductos.Refresh();
                ValidarCantidadySiEsOferta();
                CalcularTotal();
            }
        }
        private void EditarCantidad(ItemVentaDTO item)
        {
            var input = Microsoft.VisualBasic.Interaction.InputBox(
                "Ingrese nueva cantidad:",
                "Modificar cantidad",
                item.Cantidad.ToString()
            );

            if (int.TryParse(input, out int nuevaCantidad) && nuevaCantidad > 0)
            {
                item.Cantidad = nuevaCantidad;
                dgvProductos.Refresh();
                CalcularTotal();
            }
        }

        private void txtDescuentoEfectivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            // permitir control (backspace)
            if (char.IsControl(e.KeyChar))
                return;

            // permitir números
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            new VolverAlInicio(this).Volver();
        }
    }
}
