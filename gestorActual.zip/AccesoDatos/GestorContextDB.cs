﻿using AccesoDatos.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public class GestorContextDB : DbContext
    {

        public GestorContextDB(DbContextOptions<GestorContextDB> options) : base(options) { }
        public DbSet<Persona> Personas { get; set; }
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<UsuarioSesion> Usuarios { get; set; }
        public DbSet<DetallesVenta> DetallesVentas { get; set; }
        public DbSet<Venta> Ventas { get; set; }
        public DbSet<VentaLibre> VentasLibres { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<TipoPago> TiposPago { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Movimiento> Movimientos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Marca> Marcas { get; set; }
        public DbSet<Rubro> Rubros { get; set; }
        public DbSet<EmpleadoRol> EmpleadoRoles { get; set; }
        public DbSet<CategoriaProducto> CategoriasProductos { get; set; }
        public DbSet<VentaPagoDetalle> VentaPagosDetalles { get; set; }
        public DbSet<OfertaDescuento> OfertasDescuentos { get; set; }
        public DbSet<ProductosEnOfertaDescuentos> ProductosEnOfertasDescuentos { get; set; }

        public DbSet<OfertaProductoEstadistica> OfertaProductoEstadisticas { get; set; }
        public DbSet<Cliente> Cliente { get; set; }
        public DbSet<CuentaCorriente> CuentaCorriente { get; set; }
        public DbSet<CuentaCorrienteAutorizado> CuentaCorrienteAutorizados { get; set; }
        public DbSet<Caja> Cajas { get; set; }
        public DbSet<Gasto> Gastos { get; set; }
        public DbSet<Lote> Lotes { get; set; }
        public DbSet<DetalleVentaLote> DetalleVentaLotes { get; set; }
        public DbSet<CodigoRecuperacionPass> CodigosRecuperacionPass { get; set; }
        public DbSet<NotaRapida> NotasRapidas { get; set; }
        public DbSet<Permiso> Permisos { get; set; }
        public DbSet<RolPermiso> RolesPermisos { get; set; }
        public DbSet<Notificacion> Notificaciones { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);

            // PERSONA
            modelBuilder.Entity<Persona>(entity =>
            {
                entity.ToTable("Personas");

                entity.HasKey(p => p.PersonaId);

                entity.Property(p => p.PersonaId)
                      .ValueGeneratedOnAdd();
                entity.Property(p => p.Nombre).HasMaxLength(50).IsRequired();
                entity.Property(p => p.Apellido).HasMaxLength(50).IsRequired();
                entity.Property(p => p.Dni).HasMaxLength(15).IsRequired();
                entity.Property(p => p.Cuil).HasMaxLength(15).IsRequired();
                entity.Property(p => p.Telefono).HasMaxLength(20).IsRequired();

                entity.Property(p => p.Telefono2).HasMaxLength(20);
                entity.Property(p => p.Email).HasMaxLength(100);
                entity.Property(p => p.Direccion).HasMaxLength(100);

                entity.Property(p => p.FechaNacimiento).HasColumnType("date");
                entity.Property(p => p.EstaEliminado).IsRequired();

                /*entity.HasOne(p => p.Empleado)
                      .WithOne(e => e.Persona)
                      .HasForeignKey<Empleado>(e => e.PersonaId)
                      .OnDelete(DeleteBehavior.Restrict);*/


            });

            // EMPLEADO
            modelBuilder.Entity<Empleado>(entity =>
            {
                entity.ToTable("Empleados");
                entity.HasKey(e => e.PersonaId);
                entity.Property(e => e.PersonaId).HasColumnName("PersonaId");
                entity.Property(e => e.Legajo).HasColumnName("legajo").HasMaxLength(20);
                entity.Property(e => e.FechaIngreso).HasColumnName("fechaIngreso").HasColumnType("date");
                entity.Property(e => e.FechaEgreso).HasColumnName("fechaEgreso").HasColumnType("date");
                entity.Property(e => e.Estado).HasColumnName("estado").IsRequired();
                entity.Property(e => e.Username).HasColumnName("username").HasMaxLength(100);
                entity.Property(e => e.Pass).HasColumnName("pass").HasMaxLength(200);
                entity.Property(e => e.UsuarioEstaHabilitado).HasColumnName("usuarioestahabilitado");

                // Relación 1 a 1 con Persona
                entity.HasOne(e => e.Persona)
                      .WithOne()
                      .HasForeignKey<Empleado>(e => e.PersonaId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            //PRODUCTO
            modelBuilder.Entity<Producto>(entity =>
            {
                entity.ToTable("Productos");

                entity.HasKey(p => p.ProductoId);

                entity.Property(p => p.ProductoId)
                    .HasColumnName("ProductoId");

                entity.Property(p => p.Stock)
                    .HasColumnName("stock")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                entity.Property(p => p.PrecioCosto)
                    .HasColumnName("precio_costo")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                entity.Property(p => p.PrecioVenta)
                    .HasColumnName("precio_venta")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                entity.Property(p => p.Descripcion)
                    .HasColumnName("descripcion")
                    .HasMaxLength(1000);

                entity.Property(p => p.EstaEliminado)
                    .HasColumnName("esta_eliminado")
                    .IsRequired();

                entity.Property(p => p.Estado)
                    .HasColumnName("estado");

                entity.Property(p => p.Medida)
                    .HasColumnName("medida")
                    .HasMaxLength(20);

                entity.Property(p => p.UnidadMedida)
                    .HasColumnName("unidad_medida")
                    .HasMaxLength(50);

                entity.Property(p => p.Codigo)
                    .HasColumnName("codigo")
                    .HasMaxLength(50);

                entity.Property(p => p.CodigoBarra)
                    .HasColumnName("codigo_barra")
                    .HasMaxLength(50);

                entity.Property(p => p.IvaIncluidoPrecioFinal)
                    .HasColumnName("iva_inluido_precio_final")
                    .IsRequired();

                entity.Property(p => p.EsFraccionable)
                    .HasColumnName("es_fraccionable")
                    .IsRequired();

                entity.Property(p => p.IdMarca)
                    .HasColumnName("id_Marca");

                entity.Property(p => p.IdRubro)
                    .HasColumnName("id_Rubro");

                entity.Property(p => p.ControlPorLote)
                    .HasColumnName("control_por_lote")
                    .IsRequired();

                entity.Property(p => p.TieneVencimiento)
                    .HasColumnName("tiene_vencimiento")
                    .IsRequired();

                // 🔗 Relaciones con Marca
                entity.HasOne(p => p.Marca)
                    .WithMany(m => m.Productos)
                    .HasForeignKey(p => p.IdMarca);

                // 🔗 Relaciones con Rubro
                entity.HasOne(p => p.Rubro)
                    .WithMany(r => r.Productos)
                    .HasForeignKey(p => p.IdRubro);

                // 🔗 Relación con DetallesVenta
                entity.HasMany(p => p.DetallesVentas)
                    .WithOne(dv => dv.Producto)
                    .HasForeignKey(dv => dv.IdProducto)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasMany(p => p.EstadisticasOferta)
          .WithOne(x => x.Producto)
          .HasForeignKey(x => x.ProductoId)
          .OnDelete(DeleteBehavior.Restrict);

                entity.HasMany(p => p.ProductosEnOfertaDescuentos)
    .WithOne(x => x.Producto)
    .HasForeignKey(x => x.ProductoId);

            });


            // DETALLEVENTA
            modelBuilder.Entity<DetallesVenta>(entity =>
            {
                entity.ToTable("DetallesVenta");

                entity.HasKey(e => e.DetalleVentaId);

                entity.Property(e => e.DetalleVentaId)
                    .HasColumnName("id_DetalleVenta");

                entity.Property(e => e.IdVenta)
                    .HasColumnName("id_Venta")
                    .IsRequired();

                entity.Property(e => e.IdProducto)
                    .HasColumnName("id_Producto")
                    .IsRequired(false);

                entity.Property(e => e.IdOfertaDescuento)
                    .HasColumnName("id_OfertaDescuento")
                    .IsRequired(false);

                entity.Property(e => e.Cantidad)
                    .HasColumnName("cantidad")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                // 🔹 Precio original
                entity.Property(e => e.PrecioUnitarioOriginal)
                    .HasColumnName("precio_unitario_original")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                // 🔹 Precio final aplicado
                entity.Property(e => e.PrecioUnitarioFinal)
                    .HasColumnName("precio_unitario_final")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                // 🔹 Subtotal final
                entity.Property(e => e.Subtotal)
                    .HasColumnName("subtotal")
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();

                // 🔥 Flags
                entity.Property(e => e.EsOferta)
                    .HasColumnName("es_oferta")
                    .IsRequired();

                entity.Property(e => e.EsOfertaPorGrupo)
                    .HasColumnName("es_oferta_por_grupo")
                    .IsRequired();

                // 🔹 Descripción congelada
                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasMaxLength(500)
                    .IsRequired();

                // 🔗 Relaciones
                entity.HasOne(d => d.Venta)
                    .WithMany(v => v.DetallesVentas)
                    .HasForeignKey(d => d.IdVenta)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.Producto)
                    .WithMany(p => p.DetallesVentas)
                    .HasForeignKey(d => d.IdProducto)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.OfertaDescuento)
                    .WithMany(o => o.DetallesVentas)
                    .HasForeignKey(d => d.IdOfertaDescuento)
                    .OnDelete(DeleteBehavior.Restrict);
            });

                // VENTA
                modelBuilder.Entity<Venta>(entity =>
                {
                    entity.ToTable("Ventas");

                    entity.HasKey(e => e.VentaId);

                    entity.Property(e => e.VentaId)
                        .HasColumnName("id_Venta");

                    entity.Property(e => e.IdEmpleado)
                        .HasColumnName("id_Empleado")
                        .IsRequired();

                    entity.Property(e => e.IdVendedor)
                        .HasColumnName("id_Vendedor")
                        .IsRequired();

                    entity.Property(e => e.IdCliente)
                        .HasColumnName("id_cliente")
                        .IsRequired(false);


                    entity.Property(e => e.NumeroVenta)
                        .HasColumnName("numero_venta")
                        .HasMaxLength(200);

                    entity.Property(e => e.FechaVenta)
                        .HasColumnName("fecha_venta")
                        .HasColumnType("datetime2")
                        .IsRequired();

                    entity.Property(e => e.Total)
                        .HasColumnName("total")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.TotalSinDescuento)
                        .HasColumnName("total_sin_descuento")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.Descuento)
                        .HasColumnName("descuento")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.Estado)
                        .HasColumnName("estado")
                        .IsRequired();

                    entity.Property(e => e.Detalle)
                        .HasColumnName("detalle")
                        .HasMaxLength(2000);

                    entity.Property(e => e.MontoAdeudado)
                        .HasColumnName("monto_adeudado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.MontoPagado)
                        .HasColumnName("monto_pagado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    // Relaciones
                    entity.HasOne(e => e.Empleado)
                        .WithMany(emp => emp.Ventas)
                        .HasForeignKey(e => e.IdEmpleado)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(e => e.Vendedor)
                        .WithMany() // o .WithMany(emp => emp.VentasComoVendedor) si definís la colección
                        .HasForeignKey(e => e.IdVendedor)
                        .OnDelete(DeleteBehavior.Restrict);
                    entity.HasOne(e => e.Cliente)
                        .WithMany()
                        .HasForeignKey(e => e.IdCliente)
                        .OnDelete(DeleteBehavior.Restrict);

                    // 🔥 Índices para performance de ObtenerVentas (filtros, orden y paginación)

                    // Descendente para calzar EXACTO con ORDER BY FechaVenta DESC,
                    // y cubriente (INCLUDE) para que SQL Server no necesite key lookups
                    // al recorrer/descartar filas durante el Skip. Esto es lo que evita
                    // el sort-spill a tempdb que se activaba a partir de cierta página.
                    entity.HasIndex(e => e.FechaVenta)
                        .HasDatabaseName("IX_Ventas_FechaVenta_Desc")
                        .IsDescending(true)
                        .IncludeProperties(e => new
                        {
                            e.Estado,
                            e.NumeroVenta,
                            e.Total,
                            e.Detalle,
                            e.IdCliente
                        });

                    // Compuesto: útil para el caso "Estado = X" exacto (cbx2) + rango de fecha
                    entity.HasIndex(e => new { e.Estado, e.FechaVenta })
                        .HasDatabaseName("IX_Ventas_Estado_FechaVenta");

                    // Cubre: búsqueda por NumeroVenta
                    entity.HasIndex(e => e.NumeroVenta)
                        .HasDatabaseName("IX_Ventas_NumeroVenta");

                    entity.HasMany(e => e.DetallesVentas)
                        .WithOne(dv => dv.Venta)
                        .HasForeignKey(dv => dv.IdVenta)
                        .OnDelete(DeleteBehavior.Cascade);



                    entity.HasMany(e => e.VentaPagoDetalles)
                        .WithOne(vp => vp.Venta)
                        .HasForeignKey(vp => vp.IdVenta)
                        .OnDelete(DeleteBehavior.Cascade);
                });
                modelBuilder.Entity<VentaLibre>(entity =>
                {
                    entity.ToTable("VentasLibres");

                    entity.HasKey(e => e.VentaLibreId);

                    entity.Property(e => e.VentaLibreId)
                        .HasColumnName("id_VentaLibre");

                    entity.Property(e => e.IdEmpleado)
                        .HasColumnName("id_Empleado")
                        .IsRequired();

                    entity.Property(e => e.IdVendedor)
                        .HasColumnName("id_Vendedor")
                        .IsRequired();

                    entity.Property(e => e.IdCliente)
                        .HasColumnName("id_cliente")
                        .IsRequired(false);


                    entity.Property(e => e.NumeroVenta)
                        .HasColumnName("numero_venta")
                        .HasMaxLength(200);

                    entity.Property(e => e.FechaVenta)
                        .HasColumnName("fecha_venta")
                        .HasColumnType("datetime2")
                        .IsRequired();

                    entity.Property(e => e.Total)
                        .HasColumnName("total")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.Estado)
                        .HasColumnName("estado")
                        .IsRequired();

                    entity.Property(e => e.Detalle)
                        .HasColumnName("detalle")
                        .HasMaxLength(500);

                    entity.Property(e => e.MontoAdeudado)
                        .HasColumnName("monto_adeudado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.MontoPagado)
                        .HasColumnName("monto_pagado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    // Relaciones
                    entity.HasOne(e => e.Empleado)
                        .WithMany(emp => emp.VentasLibres)
                        .HasForeignKey(e => e.IdEmpleado)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(e => e.Vendedor)
                        .WithMany() // o .WithMany(emp => emp.VentasComoVendedor) si definís la colección
                        .HasForeignKey(e => e.IdVendedor)
                        .OnDelete(DeleteBehavior.Restrict);
                    entity.HasOne(e => e.Cliente)
                        .WithMany()
                        .HasForeignKey(e => e.IdCliente)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasMany(e => e.VentaPagoDetalles)
                        .WithOne(vp => vp.VentaLibre)
                        .HasForeignKey(vp => vp.IdVentaLibre)
                        .OnDelete(DeleteBehavior.Cascade);

                    // Mismo patrón que Ventas: la pantalla de consulta pagina
                    // ordenando por FechaVenta DESC
                    entity.HasIndex(e => e.FechaVenta)
                        .HasDatabaseName("IX_VentasLibres_FechaVenta_Desc")
                        .IsDescending()
                        .IncludeProperties(e => new
                        {
                            e.Estado,
                            e.NumeroVenta,
                            e.Total,
                            e.IdCliente
                        });
                });

                //VENTA PAGO DETALLE
                modelBuilder.Entity<VentaPagoDetalle>(entity =>
                {
                    entity.ToTable("VentaPagoDetalles");

                    entity.HasKey(e => e.VentaPagoDetalleId);

                    entity.Property(e => e.VentaPagoDetalleId)
                        .HasColumnName("id_VentaPagoDetalle");

                    entity.Property(e => e.IdVenta)
                        .HasColumnName("id_Venta")
                        .IsRequired(false); // puede ser null si es gasto

                    entity.Property(e => e.IdGasto)
                        .HasColumnName("id_Gasto")
                        .IsRequired(false); // puede ser null si es venta

                    entity.Property(e => e.IdTipoPago)
                        .HasColumnName("id_TipoPago")
                        .IsRequired();

                    entity.Property(e => e.Monto)
                        .HasColumnName("monto")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();
                    entity.Property(e => e.ExtraDescripcionPago)
                        .HasColumnName("extra_descripcion_pago")
                        .HasMaxLength(50)
                        .IsRequired();

                    // Relaciones

                    entity.HasOne(e => e.Venta)
                        .WithMany(v => v.VentaPagoDetalles)
                        .HasForeignKey(e => e.IdVenta)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(e => e.Gasto)
                        .WithMany(g => g.VentaPagoDetalles)
                        .HasForeignKey(e => e.IdGasto)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(e => e.TipoPago)
                        .WithMany()
                        .HasForeignKey(e => e.IdTipoPago)
                        .OnDelete(DeleteBehavior.Restrict);
                });


                //TIPO PAGO
                modelBuilder.Entity<TipoPago>(entity =>
                {
                    entity.ToTable("TiposPago");

                    entity.HasKey(tp => tp.TipoPagoId);

                    entity.Property(tp => tp.TipoPagoId)
                        .HasColumnName("id_TipoPago");

                    entity.Property(tp => tp.Nombre)
                        .HasColumnName("nombre")
                        .HasMaxLength(100)
                        .IsRequired();
                    entity.Property(tp => tp.NumeroReferencia)
                    .HasColumnName("numero_referencia")
                    .IsRequired();

                    entity.Property(tp => tp.MetodoPagoHabilitado)
                                .HasColumnName("metodo_pago_habilitado");

                    entity.Property(tp => tp.Detalle)
                        .HasColumnName("detalle")
                        .HasMaxLength(250);

                    entity.Property(tp => tp.Codigo)
                        .HasColumnName("codigo")
                        .HasMaxLength(50);
                });

                //ROL
                modelBuilder.Entity<Rol>(entity =>
                {
                    entity.ToTable("Roles");

                    entity.HasKey(e => e.RolId);

                    entity.Property(e => e.RolId)
                        .HasColumnName("id_Rol");

                    entity.Property(e => e.Nombre)
                        .HasColumnName("nombre")
                        .HasMaxLength(100)
                        .IsRequired();

                    entity.Property(e => e.DetalleRol)
                        .HasColumnName("detalleRol")
                        .HasMaxLength(200)
                        .IsRequired();

                    entity.Property(e => e.CodigoRol)
                        .HasColumnName("codigo_rol")
                        .HasMaxLength(50)
                        .IsRequired();

                    entity.HasIndex(e => e.CodigoRol)
                        .IsUnique();
                });

                // CATEGORIA
                modelBuilder.Entity<Categoria>(entity =>
                {
                    entity.ToTable("Categorias");

                    entity.HasKey(e => e.CategoriaId);
                    entity.Property(e => e.Nombre)
                          .IsRequired()
                          .HasMaxLength(100);
                });

                // MARCA
                modelBuilder.Entity<Marca>(entity =>
                {
                    entity.ToTable("Marcas");

                    entity.HasKey(e => e.MarcaId);
                    entity.Property(e => e.Nombre)
                          .IsRequired()
                          .HasMaxLength(100);
                    entity.HasMany(m => m.Productos)
                          .WithOne(p => p.Marca)
                          .HasForeignKey(p => p.IdMarca);
                });

                // RUBRO
                modelBuilder.Entity<Rubro>(entity =>
                {
                    entity.ToTable("Rubros");

                    entity.HasKey(e => e.RubroId);
                    entity.Property(e => e.Nombre)
                          .IsRequired()
                          .HasMaxLength(100);
                    entity.HasMany(m => m.Productos)
                          .WithOne(p => p.Rubro)
                          .HasForeignKey(p => p.IdRubro);
                });

                //EMPELADO ROL
                modelBuilder.Entity<EmpleadoRol>(entity =>
                {
                    entity.ToTable("Empleados_Roles");

                    entity.HasKey(e => e.EmpleadoRolId);

                    entity.Property(e => e.FechaAsignacion)
                          .HasColumnType("date");

                    entity.HasOne(e => e.Empleado)
                          .WithMany(e => e.EmpleadoRoles)
                          .HasForeignKey(e => e.IdEmpleado)
                          .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(e => e.Rol)
                          .WithMany(r => r.EmpleadosRoles)
                          .HasForeignKey(e => e.IdRol)
                          .OnDelete(DeleteBehavior.Restrict);
                });

                //CATEGORIA PRODUCTO
                modelBuilder.Entity<CategoriaProducto>(entity =>
                {
                    entity.ToTable("Categorias_Productos");

                    entity.HasKey(e => e.CategoriaProductoId);

                    entity.HasOne(cp => cp.Producto)
                          .WithMany(p => p.CategoriasProductos)
                          .HasForeignKey(cp => cp.IdProducto)
                          .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(cp => cp.Categoria)
                          .WithMany(c => c.CategoriasProductos)
                          .HasForeignKey(cp => cp.IdCategoria)
                          .OnDelete(DeleteBehavior.Restrict);
                });
                modelBuilder.Entity<OfertaDescuento>(entity =>
                {
                    entity.ToTable("OfertasDescuentos");

                    entity.HasKey(o => o.OfertaDescuentoId);

                    entity.Property(o => o.OfertaDescuentoId)
                        .HasColumnName("id_OfertaDescuento");

                    entity.Property(o => o.Descripcion)
                        .HasColumnName("descripcion")
                        .HasMaxLength(500)
                        .IsRequired();

                    entity.Property(o => o.Codigo)
                        .HasColumnName("codigo")
                        .HasMaxLength(150)
                        .IsRequired();

                    entity.Property(o => o.FechaInicio)
                        .HasColumnName("fecha_inicio")
                        .HasColumnType("date")
                        .IsRequired();

                    entity.Property(o => o.FechaFin)
                        .HasColumnName("fecha_fin")
                        .HasColumnType("date");

                    entity.Property(o => o.EstaActiva)
                        .HasColumnName("esta_activa")
                        .IsRequired();

                    entity.Property(o => o.TipoOferta)
                        .HasColumnName("tipo_oferta")
                        .IsRequired();

                    entity.Property(o => o.PorcentajeDescuento)
                        .HasColumnName("porcentaje_descuento")
                        .HasColumnType("decimal(5,2)");

                    entity.Property(o => o.PrecioFinal)
                        .HasColumnName("precio_final")
                        .HasColumnType("decimal(18,2)");

                    entity.HasMany(o => o.Productos)
                        .WithOne(p => p.OfertaDescuento)
                        .HasForeignKey(p => p.OfertaDescuentoId)
                        .OnDelete(DeleteBehavior.Cascade);

                    entity.HasMany(o => o.DetallesVentas)
                        .WithOne(d => d.OfertaDescuento)
                        .HasForeignKey(d => d.IdOfertaDescuento)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasMany(o => o.Estadisticas)
                        .WithOne(e => e.OfertaDescuento)
                        .HasForeignKey(e => e.OfertaDescuentoId)
                        .OnDelete(DeleteBehavior.Cascade);
                });
                modelBuilder.Entity<ProductosEnOfertaDescuentos>(entity =>
                {
                    entity.ToTable("ProductosEnOfertaDescuentos");

                    entity.HasKey(x => new
                    {
                        x.ProductoId,
                        x.OfertaDescuentoId
                    });

                    entity.Property(x => x.ProductoId)
                        .HasColumnName("id_Producto");

                    entity.Property(x => x.OfertaDescuentoId)
                        .HasColumnName("id_OfertaDescuento");

                    entity.Property(x => x.CantidadRequerida)
                        .HasColumnName("cantidad_requerida")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.PrecioVentaBase)
                        .HasColumnName("precio_venta_base")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.PrecioCostoBase)
                        .HasColumnName("precio_costo_base")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.PrecioOfertaBase)
                        .HasColumnName("precio_oferta_base")
                        .HasColumnType("decimal(18,2)");

                    entity.Property(x => x.LimiteVentaProducto)
                        .HasColumnName("limite_venta_producto")
                        .HasColumnType("decimal(18,2)");

                    entity.HasOne(x => x.Producto)
                        .WithMany(p => p.ProductosEnOfertaDescuentos)
                        .HasForeignKey(x => x.ProductoId)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(x => x.OfertaDescuento)
                        .WithMany(x => x.Productos)
                        .HasForeignKey(x => x.OfertaDescuentoId)
                        .OnDelete(DeleteBehavior.Cascade);



                    entity.HasIndex(x => x.ProductoId);

                    entity.HasIndex(x => x.OfertaDescuentoId);
                });
                modelBuilder.Entity<OfertaProductoEstadistica>(entity =>
                {
                    entity.ToTable("OfertaProductoEstadisticas");

                    // PK compuesta
                    entity.HasKey(x => new
                    {
                        x.OfertaDescuentoId,
                        x.ProductoId
                    });

                    entity.HasIndex(x => new
                    {
                        x.OfertaDescuentoId,
                        x.ProductoId
                    }).IsUnique();

                    entity.Property(x => x.OfertaDescuentoId)
                        .HasColumnName("id_OfertaDescuento")
                        .IsRequired();

                    entity.Property(x => x.ProductoId)
                        .HasColumnName("id_Producto")
                        .IsRequired();

                    entity.Property(x => x.CantidadVendida)
                        .HasColumnName("cantidad_vendida")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.TotalCostoAcumulado)
                        .HasColumnName("total_costo_acumulado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.TotalVentaAcumulado)
                        .HasColumnName("total_venta_acumulado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.TotalOfertaAcumulado)
                        .HasColumnName("total_oferta_acumulado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(x => x.FechaUltimaVenta)
                        .HasColumnName("fecha_ultima_venta")
                        .HasColumnType("datetime");

                    // Relación con OfertaDescuento
                    entity.HasOne(x => x.OfertaDescuento)
                        .WithMany(o => o.Estadisticas)
                        .HasForeignKey(x => x.OfertaDescuentoId)
                        .OnDelete(DeleteBehavior.Cascade);

                    // Relación con Producto
                    entity.HasOne(x => x.Producto)
                        .WithMany(p => p.EstadisticasOferta)
                        .HasForeignKey(x => x.ProductoId)
                        .OnDelete(DeleteBehavior.Restrict);
                });
                // CUENTA CORRIENTE
                modelBuilder.Entity<CuentaCorriente>(entity =>
                {
                    entity.ToTable("CuentasCorrientes");
                    entity.HasKey(cc => cc.CuentaCorrienteId);
                    entity.Property(cc => cc.CuentaCorrienteId)
                          .HasColumnName("CuentaCorrienteId")
                          .ValueGeneratedOnAdd();
                    entity.Property(cc => cc.ClienteId)
                          .HasColumnName("ClienteId")
                          .IsRequired();
                    entity.Property(cc => cc.NombreCuentaCorriente)
                          .HasColumnName("nombre_cuenta_corriente")
                          .HasMaxLength(100)
                          .IsRequired();
                    entity.Property(cc => cc.Saldo)
                          .HasColumnName("saldo")
                          .HasColumnType("decimal(18,2)")
                          .IsRequired();
                    entity.Property(cc => cc.LimiteDeuda)
                          .HasColumnName("limite_deuda")
                          .HasColumnType("decimal(18,2)")
                          .IsRequired();
                    entity.Property(cc => cc.LimiteDeudaActivo)
                          .HasColumnName("limite_deuda_activo")
                          .IsRequired();
                    entity.Property(cc => cc.FechaVencimiento)
                          .HasColumnName("fecha_vencimiento")
                          .HasColumnType("date");
                    entity.Property(cc => cc.EstaEliminado)
                          .HasColumnName("esta_eliminado")
                          .IsRequired();
                    entity.Property(cc => cc.FechaActivacion)
                        .HasColumnName("fecha_activacion")
                        .HasColumnType("date");
                    entity.Property(cc => cc.FechaCreacion)
                        .HasColumnName("fecha_creacion")
                        .HasColumnType("date");
                    entity.Property(cc=>cc.TipoVencimiento)
                        .HasColumnName("tipo_vencimiento")
                        .IsRequired();
                    entity.Property(cc => cc.ConDeuda)
                        .HasColumnName("con_deuda")
                        .IsRequired();
                    entity.Property(cc => cc.CantidadMesesVencimiento)
                        .HasColumnName("cantidad_meses_vencimiento")
                        .IsRequired();

                    // Relación uno a uno con Cliente
                    entity.HasOne(cc => cc.Cliente)
                          .WithOne(c => c.CuentaCorriente)
                          .HasForeignKey<Cliente>(c => c.CuentaCorrienteId)
                          .OnDelete(DeleteBehavior.Restrict);
                    // Relación uno a muchos con CuentaCorrienteAutorizado
                    entity.HasMany(c => c.CuentaCorrienteAutorizado)
                          .WithOne() // sin navegación inversa
                          .HasForeignKey(a => a.CuentaCorrienteId)
                          .OnDelete(DeleteBehavior.Cascade);
                });

                // CLIENTE
                modelBuilder.Entity<Cliente>(entity =>
                {
                    entity.ToTable("Clientes");
                    entity.HasKey(c => c.PersonaId);
                    entity.Property(c => c.PersonaId)
                          .HasColumnName("PersonaId");
                    entity.Property(c => c.CuentaCorrienteId)
                          .HasColumnName("CuentaCorrienteId");
                    entity.Property(c => c.NumeroCliente)
                          .HasColumnName("numero_cliente")
                          .HasMaxLength(50)
                          .IsRequired();
                    entity.Property(c => c.FechaAlta)
                          .HasColumnName("fecha_alta")
                          .HasColumnType("date")
                          .IsRequired();
                    entity.Property(c => c.FechaBaja)
                          .HasColumnName("fecha_baja")
                          .HasColumnType("date");
                    entity.Property(c => c.Estado)
                          .HasColumnName("estado")
                          .IsRequired();
                    entity.Property(c => c.EstadoDescripcion)
                          .HasColumnName("estado_descripcion")
                          .HasMaxLength(200);
                    // Relación 1 a 1 con Persona
                    entity.HasOne(c => c.Persona)
                          .WithOne()
                          .HasForeignKey<Cliente>(c => c.PersonaId)
                          .OnDelete(DeleteBehavior.Restrict);
                    // Relación uno a uno con CuentaCorriente
                    entity.HasOne(c => c.CuentaCorriente)
                          .WithOne(cc => cc.Cliente)
                          .HasForeignKey<CuentaCorriente>(c => c.ClienteId)
                          .OnDelete(DeleteBehavior.Restrict);
                });

                // CUENTA CORRIENTE AUTORIZADO
                modelBuilder.Entity<CuentaCorrienteAutorizado>(entity =>
                {
                    entity.ToTable("CuentaCorrienteAutorizados");
                    entity.HasKey(cca => cca.CuentaCorrienteAutorizadoId);

                    entity.Property(cca => cca.CuentaCorrienteAutorizadoId)
                          .HasColumnName("CuentaCorrienteAutorizadoId")
                          .ValueGeneratedOnAdd();
                    entity.Property(cca => cca.CuentaCorrienteId)
                          .HasColumnName("CuentaCorrienteId")
                          .IsRequired();
                    entity.Property(cca => cca.Dni)
                          .HasColumnName("dni")
                          .IsRequired();
                });

                // CAJA
                modelBuilder.Entity<Caja>(entity =>
                {
                    entity.ToTable("Cajas");
                    entity.HasKey(c => c.CajaId);
                    entity.Property(c => c.CajaId)
                          .HasColumnName("CajaId")
                          .ValueGeneratedOnAdd();
                    entity.Property(c => c.SaldoInicial)
                          .HasColumnName("saldo_inicial")
                          .HasColumnType("decimal(18,2)")
                          .IsRequired();
                    entity.Property(c => c.SaldoActual)
                          .HasColumnName("saldo_actual")
                          .HasColumnType("decimal(18,2)")
                          .IsRequired();
                    entity.Property(c => c.FechaInicio)
                            .HasColumnName("fecha_apertura")
                            .HasColumnType("datetime")
                            .IsRequired();
                    entity.Property(c => c.FechaFin)
                            .HasColumnName("fecha_cierre")
                            .HasColumnType("datetime");
                    entity.Property(c => c.TotalIngresos)
                            .HasColumnName("total_ingresos")
                            .HasColumnType("decimal");
                    entity.Property(c => c.TotalEgresos)
                            .HasColumnName("total_egresos")
                            .HasColumnType("decimal");
                    entity.Property(c => c.BalanceFinal)
                            .HasColumnName("balance_final")
                            .HasColumnType("decimal");
                    entity.Property(c => c.EmpleadoApertura)
                            .HasColumnName("empleado_apertura")
                            .HasColumnType("bigint").IsRequired();
                    entity.Property(c => c.EmpleadoCierre)
                            .HasColumnName("empleado_cierre")
                            .HasColumnType("bigint");
                    entity.Property(c => c.EstaCerrada)
                            .HasColumnName("esta_cerrada")
                            .IsRequired();

                    // Se consulta constantemente ordenando por FechaInicio DESC
                    // (turno actual, historial de cajas, cierre de caja)
                    entity.HasIndex(c => c.FechaInicio)
                        .HasDatabaseName("IX_Cajas_FechaInicio_Desc")
                        .IsDescending();

                    // Caso muy frecuente: "traer la caja abierta" -> EstaCerrada = false
                    entity.HasIndex(c => c.EstaCerrada)
                        .HasDatabaseName("IX_Cajas_EstaCerrada");

                });

                modelBuilder.Entity<Movimiento>(entity =>
                {
                    entity.ToTable("Movimientos");

                    entity.HasKey(e => e.MovimientoId);

                    entity.Property(e => e.MovimientoId)
                        .HasColumnName("id_movimiento");

                    entity.Property(e => e.NumeroMovimiento)
                        .HasColumnName("numero_movimiento")
                        .HasMaxLength(100)
                        .IsRequired();

                    entity.Property(e => e.TipoMovimiento)
                        .HasColumnName("tipo_movimiento")
                        .IsRequired();

                    entity.Property(e => e.TipoMovimientoDetalle)
                        .HasColumnName("tipo_movimiento_detalle")
                        .IsRequired();

                    entity.Property(e => e.Monto)
                        .HasColumnName("monto")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.FechaMovimiento)
                        .HasColumnName("fecha_movimiento")
                        .HasColumnType("datetime")
                        .IsRequired();

                    entity.Property(e => e.EstaEliminado)
                        .HasColumnName("esta_eliminado")
                        .IsRequired();

                    entity.Property(e => e.EntidadId)
                        .HasColumnName("entidad_id")
                        .IsRequired(false);

                    entity.Property(e => e.TipoEntidad)
                        .HasColumnName("tipo_entidad")
                        .IsRequired(false);

                    // Mismo patrón: consulta de movimientos ordena por FechaMovimiento DESC
                    entity.HasIndex(e => e.FechaMovimiento)
                        .HasDatabaseName("IX_Movimientos_FechaMovimiento_Desc")
                        .IsDescending();
                });

                //GASTO
                modelBuilder.Entity<Gasto>(entity =>
                {
                    entity.ToTable("Gastos");

                    entity.HasKey(e => e.GastoId);

                    entity.Property(e => e.GastoId)
                        .HasColumnName("id_Gasto");

                    entity.Property(e => e.NumeroGasto)
                        .HasColumnName("numero_gasto")
                        .HasMaxLength(200)
                        .IsRequired();

                    entity.Property(e => e.IdEmpleado)
                        .HasColumnName("id_Empleado")
                        .IsRequired();

                    entity.Property(e => e.CategoriaGasto)
                        .HasColumnName("categoria_gasto")
                        .IsRequired();

                    entity.Property(e => e.FechaGasto)
                        .HasColumnName("fecha_gasto")
                        .HasColumnType("datetime2");

                    entity.Property(e => e.FechaRegistro)
                        .HasColumnName("fecha_registro")
                        .HasColumnType("datetime2")
                        .IsRequired();

                    entity.Property(e => e.MontoTotal)
                        .HasColumnName("monto_total")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.MontoPagado)
                        .HasColumnName("monto_pagado")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.EstadoGasto)
                        .HasColumnName("estado_gasto")
                        .IsRequired();

                    entity.Property(e => e.Detalle)
                        .HasColumnName("detalle")
                        .HasMaxLength(500);

                    // Relaciones

                    entity.HasOne(e => e.Empleado)
                        .WithMany() // SIN navegación inversa
                        .HasForeignKey(e => e.IdEmpleado)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasMany(e => e.VentaPagoDetalles)
                        .WithOne(vp => vp.Gasto)
                        .HasForeignKey(vp => vp.IdGasto)
                        .OnDelete(DeleteBehavior.Restrict);

                    // Índices
                    // Nota: el ORDER BY de ObtenerGastos usa una expresión calculada
                    // (EstadoGasto == Pagado, luego COALESCE(FechaGasto, FechaRegistro)),
                    // así que ningún índice evita el Sort acá. Estos índices sirven para
                    // que el filtro (WHERE) y el sort no necesiten ir a buscar cada fila
                    // a la tabla (cubrientes), pero si Gastos crece mucho el Sort puede
                    // volver a ser un cuello de botella igual que pasó en Ventas.
                    entity.HasIndex(e => e.EstadoGasto)
                        .HasDatabaseName("IX_Gastos_EstadoGasto")
                        .IncludeProperties(e => new
                        {
                            e.FechaGasto,
                            e.FechaRegistro,
                            e.NumeroGasto,
                            e.IdEmpleado,
                            e.MontoTotal,
                            e.MontoPagado,
                            e.CategoriaGasto
                        });

                    entity.HasIndex(e => e.FechaGasto);
                    entity.HasIndex(e => e.CategoriaGasto);
                });

                //LOTES
                modelBuilder.Entity<Lote>(entity =>
                {
                    entity.ToTable("Lotes");

                    entity.HasKey(e => e.LoteId);

                    entity.Property(e => e.LoteId)
                        .HasColumnName("id_Lote");

                    entity.Property(e => e.IdProducto)
                        .HasColumnName("id_Producto")
                        .IsRequired();

                    entity.Property(e => e.StockIncial)
                        .HasColumnName("stock_inicial")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.StockActual)
                        .HasColumnName("stock_actual")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.Property(e => e.NumeroLote)
                        .HasColumnName("numero_lote")
                        .HasMaxLength(200)
                        .IsRequired();

                    entity.Property(e => e.Descripcion)
                        .HasColumnName("descripcion")
                        .HasMaxLength(500);

                    entity.Property(e => e.FechaAlta)
                        .HasColumnName("fecha_alta")
                        .HasColumnType("datetime2")
                        .IsRequired();

                    entity.Property(e => e.FechaVencimiento)
                        .HasColumnName("fecha_vencimiento")
                        .HasColumnType("datetime2")
                        .IsRequired(false);

                    entity.Property(entity => entity.EstaVencido)
                        .HasColumnName("esta_vencido")
                        .IsRequired();

                    entity.Property(entity => entity.EstaActivo)
                        .HasColumnName("esta_activo")
                        .IsRequired();

                    entity.Property(entity => entity.EstaEliminado)
                        .HasColumnName("esta_eliminado")
                        .IsRequired();

                    //Relación con Producto
                    entity.HasOne(e => e.Producto)
                        .WithMany(p => p.Lotes) // o .WithMany(p => p.Lotes) si agregás la colección en Producto
                        .HasForeignKey(e => e.IdProducto)
                        .OnDelete(DeleteBehavior.Restrict);
                });

                modelBuilder.Entity<UsuarioSesion>(entity =>
                {
                    entity.ToTable("Usuarios_Sesiones");

                    entity.HasKey(e => e.UsuarioSesionId);

                    entity.Property(e => e.FechaLogin)
                          .HasColumnType("datetime");

                    entity.Property(e => e.FechaLogout)
                          .HasColumnType("datetime");

                    entity.Property(e => e.Activa)
                          .IsRequired();

                    entity.HasOne(e => e.Usuario)
                          .WithMany(u => u.Sesiones)
                          .HasForeignKey(e => e.UsuarioId)
                          .OnDelete(DeleteBehavior.Restrict);

                });

                modelBuilder.Entity<DetalleVentaLote>(entity =>
                {
                    entity.ToTable("DetalleVentaLote");

                    entity.HasKey(e => e.DetalleVentaLoteId);

                    entity.Property(e => e.IdProducto)
                        .HasColumnName("id_Producto")
                        .IsRequired();

                    entity.Property(e => e.IdVenta)
                        .HasColumnName("id_Venta")
                        .IsRequired();

                    entity.Property(e => e.IdLote)
                        .HasColumnName("id_Lote")
                        .IsRequired();

                    entity.Property(e => e.Cantidad)
                        .HasColumnName("cantidad")
                        .HasColumnType("decimal(18,2)")
                        .IsRequired();

                    entity.HasOne(d => d.Venta)
                        .WithMany(v => v.DetallesVentasLotes)
                        .HasForeignKey(d => d.IdVenta)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(d => d.Producto)
                        .WithMany(p => p.DetalleVentaLotes)
                        .HasForeignKey(d => d.IdProducto)
                        .OnDelete(DeleteBehavior.Restrict);

                    entity.HasOne(d => d.Lote)
                        .WithMany(p => p.DetalleVentaLote)
                        .HasForeignKey(d => d.IdLote)
                        .OnDelete(DeleteBehavior.Restrict);
                });

                modelBuilder.Entity<CodigoRecuperacionPass>(entity =>
                {
                    entity.ToTable("CodigosRecuperacionPass");

                    entity.HasKey(e => e.CodigoRecuperacionId);

                    entity.Property(e => e.Codigo)
                        .IsRequired()
                        .HasMaxLength(5);

                    entity.Property(e => e.FechaCreacion)
                        .IsRequired();

                    entity.Property(e => e.FechaExpiracion)
                        .IsRequired();

                    entity.Property(e => e.EstaUsado)
                        .IsRequired();

                    entity.Property(e => e.FechaUso)
                        .IsRequired(false);

                    // 🔹 Relación con Empleado
                    entity.HasOne(e => e.UsuarioAsignado)
                        .WithMany(e => e.CodigosRecuperacion)
                        .HasForeignKey(e => e.UsuarioAsignadoId)
                        .OnDelete(DeleteBehavior.Cascade);

                    // 🔹 Índice para búsquedas rápidas por código
                    entity.HasIndex(e => e.Codigo);
                });

                modelBuilder.Entity<NotaRapida>(entity =>
                {
                    entity.ToTable("NotasRapidas");
                    entity.HasKey(e => e.NotaId);
                    entity.Property(e => e.NotaId)
                        .HasColumnName("id_Nota")
                        .ValueGeneratedNever(); // Para usar un ID fijo
                    entity.Property(e => e.Cuerpo)
                        .HasColumnName("cuerpo")
                        .HasMaxLength(2000)
                        .IsRequired();
                    entity.Property(e => e.FechaModificacion)
                        .HasColumnName("fecha_modificacion")
                        .HasColumnType("datetime")
                        .IsRequired();
                    entity.Property(e => e.UsuarioNombre)
                        .HasColumnName("usuario_nombre")
                        .HasMaxLength(200);
                });

                modelBuilder.Entity<Permiso>(entity =>
                {
                    entity.ToTable("Permisos");

                    entity.HasKey(e => e.PermisoId);

                    entity.Property(e => e.PermisoId)
                        .HasColumnName("id_permiso");

                    entity.Property(e => e.Codigo)
                        .HasColumnName("codigo")
                        .HasMaxLength(100)
                        .IsRequired();

                    entity.Property(e => e.Descripcion)
                        .HasColumnName("descripcion")
                        .HasMaxLength(200);

                    // 🔥 IMPORTANTE
                    entity.HasIndex(e => e.Codigo)
                        .IsUnique();
                });

                modelBuilder.Entity<RolPermiso>(entity =>
                {
                    entity.ToTable("Roles_Permisos");

                    entity.HasKey(e => new { e.IdRol, e.IdPermiso });

                    entity.Property(e => e.IdRol)
                        .HasColumnName("id_rol");

                    entity.Property(e => e.IdPermiso)
                        .HasColumnName("id_permiso");

                    entity.HasOne(e => e.Rol)
                        .WithMany(r => r.RolesPermisos)
                        .HasForeignKey(e => e.IdRol)
                        .OnDelete(DeleteBehavior.Cascade);

                    entity.HasOne(e => e.Permiso)
                        .WithMany()
                        .HasForeignKey(e => e.IdPermiso)
                        .OnDelete(DeleteBehavior.Cascade);
                });

                modelBuilder.Entity<Notificacion>(entity =>
                {
                    entity.ToTable("Notificaciones");

                    entity.HasKey(e => e.NotificacionId);

                    entity.Property(e => e.NotificacionId)
                        .HasColumnName("id_notificacion")
                        .ValueGeneratedOnAdd();

                entity.Property(e => e.EmpleadoId)
                    .HasColumnName("empleado_id")
                    .IsRequired(false);

                    entity.Property(e => e.Titulo)
                        .HasColumnName("titulo")
                        .HasMaxLength(500)
                        .IsRequired();

                    entity.Property(e => e.Descripcion)
                        .HasColumnName("descripcion")
                        .HasMaxLength(500)
                        .IsRequired();

                    entity.Property(e => e.Mensaje)
                        .HasColumnName("mensaje")
                        .HasMaxLength(500)
                        .IsRequired();

                entity.Property(e => e.FechaVencimiento)
                    .HasColumnName("fecha_vencimiento")
                    .HasColumnType("datetime")
                    .IsRequired(false);

                entity.Property(e => e.FechaCreacion)
                    .HasColumnName("fecha_creacion")
                    .HasColumnType("datetime")
                    .IsRequired();

                entity.Property(e => e.FechaConfirmacion)
                    .HasColumnName("fecha_confirmacion")
                    .HasColumnType("datetime")
                    .IsRequired(false);

                    entity.Property(e => e.EstaLeida)
                        .HasColumnName("esta_leida")
                        .IsRequired();

                // Relación con Usuario
                entity.HasOne(e => e.Empleado)
                    .WithMany(u => u.Notificaciones)
                    .HasForeignKey(e => e.EmpleadoId)
                    .OnDelete(DeleteBehavior.SetNull);
            });
        }
    }
}