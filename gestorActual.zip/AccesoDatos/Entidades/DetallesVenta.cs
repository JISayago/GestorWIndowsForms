﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos.Entidades
{
    public class DetallesVenta
    {
        [Key]
        public long DetalleVentaId { get; set; }

        public long IdVenta { get; set; }

        public long? IdProducto { get; set; }
        public long? IdOfertaDescuento { get; set; }

        public decimal Cantidad { get; set; }

        public decimal PrecioUnitarioOriginal { get; set; }

        public decimal PrecioUnitarioFinal { get; set; }

        public decimal Subtotal { get; set; }

        public bool EsOferta { get; set; }
        public bool EsOfertaPorGrupo { get; set; }

        public string Descripcion { get; set; }

        public Venta Venta { get; set; }
        public Producto Producto { get; set; }
        public OfertaDescuento OfertaDescuento { get; set; }
    }
}
