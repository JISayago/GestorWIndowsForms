﻿using AccesoDatos;
using AccesoDatos.Entidades;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Servicios.Helpers.Producto;
using Servicios.Helpers.Sistema;
using Servicios.Helpers.Sistema.FiltrosConsulta;
using Servicios.Helpers.Venta.Oferta;
using Servicios.LogicaNegocio.Producto.DTO;
using Servicios.LogicaNegocio.Producto.Lote;
using Servicios.LogicaNegocio.Venta.DTO;
using Servicios.LogicaNegocio.Venta.Oferta.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Servicios.LogicaNegocio.Producto
{
    public class ProductoServicio : IProductoServicio
    {
        public ItemVentaDTO? ObtenerItemVenta(long productoId)
        {
            using var context = new GestorContextDBFactory().CreateDbContext(null);

            var producto = context.Productos
                .AsNoTracking()
                .Include(x => x.Marca)
                .Include(x => x.Rubro)
                .Include(x => x.CategoriasProductos)
                .FirstOrDefault(x =>
                    x.ProductoId == productoId &&
                    !x.EstaEliminado);

            if (producto == null)
                return null;

            // Solo se consideran ofertas de Producto o Grupo.
            // Los Combos y 2x1 se cargan desde el botón de ofertas.
            var productoOferta = context.ProductosEnOfertasDescuentos
                .AsNoTracking()
                .Include(x => x.OfertaDescuento)
                .FirstOrDefault(x =>
                    x.ProductoId == productoId &&
                    x.OfertaDescuento.EstaActiva &&
                    (
                        x.OfertaDescuento.TipoOferta == (int)Servicios.Helpers.Venta.Oferta.TipoOferta.Producto ||
                        x.OfertaDescuento.TipoOferta == (int)Servicios.Helpers.Venta.Oferta.TipoOferta.Grupo
                    ));

            decimal precioOferta = producto.PrecioVenta;
            bool esOferta = false;
            int tipoOferta = 0;
            string codigoOferta = "Sin Oferta";

            if (productoOferta != null)
            {
                precioOferta = productoOferta.PrecioOfertaBase ?? producto.PrecioVenta;
                esOferta = true;
                tipoOferta = productoOferta.OfertaDescuento.TipoOferta;
                codigoOferta = productoOferta.OfertaDescuento.Codigo;
            }

            return new ItemVentaDTO
            {
                ItemId = producto.ProductoId,

                Descripcion = producto.Descripcion,

                CodigoOferta = codigoOferta,

                PrecioVenta = producto.PrecioVenta,
                PrecioOferta = precioOferta,

                Cantidad = 0m,

                Stock = producto.Stock,

                Medida = producto.Medida,
                UnidadMedida = producto.UnidadMedida,

                EsOferta = esOferta,
                TipoOferta = tipoOferta
            };
        }

        public List<DetalleVentaLoteDTO> DescontarStockProductos(List<ItemVentaDTO> items,GestorContextDB context)
        {
            var detallesLotesUsados = new List<DetalleVentaLoteDTO>();

            if (items == null || !items.Any())
                return detallesLotesUsados;

            foreach (var item in items)
            {
                var producto = context.Productos
                    .FirstOrDefault(p => p.ProductoId == item.ItemId);

                if (producto == null)
                    throw new Exception($"Producto no encontrado. {item.Descripcion}");

                if (producto.Stock < item.Cantidad)
                    throw new Exception(
                        $"Stock insuficiente para {producto.Descripcion}. Stock actual: {producto.Stock}");

                if (producto.ControlPorLote)
                {
                    var loteServicio = new LoteServicio();

                    detallesLotesUsados.AddRange(
                        loteServicio.DescontarStockLoteFifoLifo(
                            item.Cantidad,
                            producto.ProductoId,
                            producto.TieneVencimiento));
                }

                producto.Stock -= item.Cantidad;

                context.Productos.Update(producto);
            }

            ModificarEstadoStockProductos(context);

            return detallesLotesUsados;
        }

        //public List<DetalleVentaLoteDTO> DescontarStockProductos(List<ItemVentaDTO> items, GestorContextDB context)
        //{
        //    //DEVUELO DETALLEVENTALOTEDTO PORQUE NO PUEDO CREAR DVL EN LOTE SERVICE, TENGO QUE HACERLO EN VENTAINTERNA
        //    var detallesLotesUsados = new List<DetalleVentaLoteDTO>();

        //    if (items == null || !items.Any())
        //        return detallesLotesUsados;

        //    foreach (var item in items)
        //    {
        //        if (item.EsOferta)
        //        {
        //            DescontarStockOferta(item, context);
        //        }
        //        else
        //        {
        //            detallesLotesUsados = DescontarStockProducto(item, context);


        //        }
        //    }
        //    ModificarEstadoStockProductos(context);
        //    return detallesLotesUsados;
        //}

        //private List<DetalleVentaLoteDTO> DescontarStockProducto(ItemVentaDTO item, GestorContextDB context)
        //{
        //    var producto = context.Productos
        //        .FirstOrDefault(p => p.ProductoId == item.ItemId);

        //    var detallesLotesUsados = new List<DetalleVentaLoteDTO>();

        //    if (producto == null)
        //        throw new Exception($"Producto no encontrado. {item.Descripcion}");

        //    if (producto.Stock < item.Cantidad)
        //        throw new Exception(
        //            $"Stock insuficiente para {producto.Descripcion}. Stock actual: {producto.Stock}"
        //        );

        //    //IF CONTROL POR LOTES ESTA ACTIVADO USAR SERVICE DE LOTE Y ADEMAS REDUCIR STOCK DEL LOTE
        //    if (producto.ControlPorLote)
        //    {
        //        LoteServicio loteServicio = new LoteServicio();

        //        detallesLotesUsados = loteServicio.DescontarStockLoteFifoLifo(item.Cantidad, producto.ProductoId, producto.TieneVencimiento);
        //        //DESCONTAR STOCK DE LOTES NOS DEVUELVE LA INFO DE LOS LOTES USADOS
        //    }

        //    producto.Stock -= item.Cantidad;

        //    context.Productos.Update(producto);

        //    ModificarEstadoStockProductos(context);

        //    return detallesLotesUsados;
        //}

        //private void DescontarStockOferta(ItemVentaDTO item, GestorContextDB context)
        //{
        //    var productosOferta = context.ProductosEnOfertasDescuentos
        //        .Where(x => x.OfertaDescuentoId == item.ItemId)
        //        .ToList();

        //    if (!productosOferta.Any())
        //        throw new Exception($"La oferta {item.Descripcion} no tiene productos asociados.");

        //    foreach (var prodOferta in productosOferta)
        //    {
        //        var producto = context.Productos
        //            .FirstOrDefault(p => p.ProductoId == prodOferta.ProductoId);

        //        if (producto == null)
        //            throw new Exception($"Producto asociado a oferta no encontrado. Codigo: {prodOferta.Producto.Codigo}");

        //        // cantidad real a descontar
        //        var cantidadADescontar = prodOferta.CantidadRequerida * item.Cantidad;

        //        if (producto.Stock < cantidadADescontar)
        //            throw new Exception(
        //                $"Stock insuficiente para {producto.Descripcion}. Stock actual: {producto.Stock}"
        //            );

        //        producto.Stock -= cantidadADescontar;

        //        context.Productos.Update(producto);
        //    }

        //    ModificarEstadoStockProductos(context);
        //}
        public void RestaurarStockProductos(List<ItemVentaDTO> items, GestorContextDB context, long ventdaId)
        {
            if (items == null || !items.Any())
                return;

            foreach (var item in items
                    .GroupBy(x => x.ItemId)
                    .Select(g => new ItemVentaDTO
                    {
                        ItemId = g.Key,
                        Cantidad = g.Sum(x => x.Cantidad)
                    }))
            {
                RestaurarStockProducto(item, context, ventdaId);
            }

            ModificarEstadoStockProductos(context);
        }

        private void RestaurarStockProducto(ItemVentaDTO item, GestorContextDB context, long ventaId)
        {
            var producto = context.Productos
                .FirstOrDefault(p => p.ProductoId == item.ItemId);

            if (producto == null)
                throw new Exception($"Producto no encontrado. {item.Descripcion}");

            if(producto.ControlPorLote)
            {
                var lotesUsadosEnVenta = context.DetalleVentaLotes
                    .Where(dvl =>
                        dvl.IdVenta == ventaId &&
                        dvl.IdProducto == item.ItemId)
                    .ToList();

                var idsLotes = lotesUsadosEnVenta.Select(x => x.IdLote).ToList();

                var lotes = context.Lotes
                    .Where(l => idsLotes.Contains(l.LoteId))
                    .ToList();

                foreach (var detalle in lotesUsadosEnVenta)
                {
                    var lote = lotes.First(l => l.LoteId == detalle.IdLote);
                    lote.StockActual += detalle.Cantidad;
                }

                    context.Lotes.UpdateRange(lotes);
            }

            producto.Stock += item.Cantidad;

            context.Productos.Update(producto);

            //ModificarEstadoStockProductos(context);


        }

        /* private void DescontarStockOferta(ItemVentaDTO item, GestorContextDB context)
         {
             var oferta = context.OfertasDescuentos
                 .Include(o => o.Descripcion)
                 .FirstOrDefault(o => o.OfertaDescuentoId == item.ItemId);

             if (oferta == null)
                 throw new Exception($"Oferta no encontrada. ID {item.ItemId}");

             foreach (var detalle in oferta.Descripcion)
             {
                 var producto = context.Productos
                     .FirstOrDefault(p => p.ProductoId == detalle.);

                 if (producto == null)
                     throw new Exception($"Producto {detalle.ProductoId} de la oferta no existe");

                 var cantidadADescontar = detalle.Cantidad * item.Cantidad;

                 if (producto.Stock < cantidadADescontar)
                     throw new Exception(
                         $"Stock insuficiente para {producto.Descripcion} (oferta)"
                     );

                 producto.Stock -= cantidadADescontar;
             }
         }*/

        public EstadoOperacion Eliminar(long productoId)
        {
            var context = new GestorContextDBFactory().CreateDbContext(null);
            var productoEliminar = context.Productos
                    .FirstOrDefault(x => x.ProductoId == productoId);

            if (productoEliminar == null) 
                throw new Exception($" No se encontro el Producto");

            productoEliminar.EstaEliminado = true;
            productoEliminar.Estado = (int)EstadoProducto.Discontinuado;

            context.SaveChanges();
            return new EstadoOperacion
            {
                Exitoso = true,
                Mensaje = $"El producto {productoEliminar.Descripcion} fue eliminado correctamente."
            };
        }

        public EstadoOperacion Insertar(ProductoDTO productoDto)
        {
            var context = new GestorContextDBFactory().CreateDbContext(null);

            if (context.Productos.Any(p => p.Descripcion == productoDto.Descripcion))
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "Ya existe un producto con el mismo nombre."
                };

            var producto = new AccesoDatos.Entidades.Producto{
                Stock = productoDto.Stock,
                ControlPorLote = productoDto.ControlPorLote,
                TieneVencimiento = productoDto.TieneVencimiento,
                PrecioCosto = productoDto.PrecioCosto,
                PrecioVenta = productoDto.PrecioVenta,
                Descripcion = productoDto.Descripcion,
                EstaEliminado = false,
                Estado = productoDto.Estado,
                Medida = productoDto.Medida,
                UnidadMedida = productoDto.UnidadMedida,
                IdMarca = productoDto.IdMarca,
                IdRubro = productoDto.IdRubro,
                Codigo = productoDto.Codigo ?? "01",
                CodigoBarra = productoDto.CodigoBarra ?? "01",
                IvaIncluidoPrecioFinal = productoDto.IvaIncluidoPrecioFinal,
                EsFraccionable = productoDto.EsFraccionable,
                CategoriasProductos = productoDto.CategoriaIds
                    .Select(id => new CategoriaProducto
                    {
                        IdCategoria = id
                        // ProductoId se setea automáticamente si EF está trackeando al Producto 
                    })
                    .ToList()
            };

            context.Productos.Add(producto);
            context.SaveChanges();
            return new EstadoOperacion
            {
                Exitoso = true,
                Mensaje = "Producto creado correctamente.",
                EntidadId = producto.ProductoId
            };
        }

        public EstadoOperacion Modificar(ProductoDTO productoDto, long? productoId)
        {
            bool? controlPorLoteActivadoDescativado = null;

            var context = new GestorContextDBFactory().CreateDbContext(null);

            var productoEditar = context.Productos
                .Include(x => x.Marca)
                .Include(x => x.CategoriasProductos)
                .FirstOrDefault(x => x.ProductoId == productoId);

            if (productoEditar == null)
            {
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "Producto no encontrado."
                };
            }

            //bool productoDuplicado ??

            productoEditar.Stock = productoDto.Stock;            

            //Verificamos si se intenta desactivar el control por lote y el producto tiene lotes asociados, en ese caso no permitimos la modificación
            if (productoEditar.ControlPorLote && !productoDto.ControlPorLote)
            {
                var tieneLotes = context.Lotes.Any(l => l.IdProducto == productoEditar.ProductoId && l.EstaActivo);
                if (tieneLotes)
                {
                    return new EstadoOperacion
                    {
                        Exitoso = false,
                        Mensaje = "No se puede desactivar el control por lote porque el producto tiene lotes asociados, deshabilite los lotes asociados al producto."
                    };
                }

                productoEditar.Stock = 0; //llevamos a 0 el stock del producto
            }

            //Verificamos si se intenta activar el control por lote 
            if (!productoEditar.ControlPorLote && productoDto.ControlPorLote)
            {
                productoEditar.Stock = 0; //llevamos a 0 el stock del producto
            }


            productoEditar.ControlPorLote = productoDto.ControlPorLote;
            productoEditar.TieneVencimiento = productoDto.TieneVencimiento;
            productoEditar.PrecioCosto = productoDto.PrecioCosto;
            productoEditar.PrecioVenta = productoDto.PrecioVenta;
            productoEditar.Descripcion = productoDto.Descripcion;
            productoEditar.EstaEliminado = productoDto.EstaEliminado;
            productoEditar.Estado = productoDto.Estado;
            productoEditar.Medida = productoDto.Medida;
            productoEditar.UnidadMedida = productoDto.UnidadMedida;
            productoEditar.IdMarca = productoDto.IdMarca;
            productoEditar.IdRubro = productoDto.IdRubro;
            productoEditar.Codigo = productoDto.Codigo;
            productoEditar.CodigoBarra = productoDto.CodigoBarra;
            productoEditar.IvaIncluidoPrecioFinal = productoDto.IvaIncluidoPrecioFinal;
            productoEditar.EsFraccionable = productoDto.EsFraccionable;

            // 🔄 CATEGORIAS (N a N): sacamos las asociaciones viejas antes de
            // cargar las nuevas, sino quedan duplicadas/viejas categorías colgadas.
            if (productoEditar.CategoriasProductos.Any())
            {
                context.CategoriasProductos.RemoveRange(productoEditar.CategoriasProductos);
                productoEditar.CategoriasProductos.Clear();
            }

            foreach (var categoriaId in productoDto.CategoriaIds ?? new List<long>())
            {
                productoEditar.CategoriasProductos.Add(new CategoriaProducto
                {
                    IdProducto = productoEditar.ProductoId,
                    IdCategoria = categoriaId
                });
            };

            ModificarEstadoStockProductos(context);
            context.SaveChanges();


            return new EstadoOperacion
            {
                Exitoso = true,
                Mensaje = "Producto modificado correctamente.",
                EntidadId = productoEditar.ProductoId
            };
        }

        public ProductoDTO ObtenerProductoPorId(long productoId)
        {
            using var context = new GestorContextDBFactory().CreateDbContext(null);

            var producto = context.Productos
                 .AsNoTracking()
                 .Include(e => e.Marca)
                 .Include(e => e.CategoriasProductos)
                 .Where(e => e.ProductoId == productoId && !e.EstaEliminado)
                 .Select(e => new ProductoDTO
                 {
                     ProductoId = e.ProductoId,
                     IdMarca = e.IdMarca,
                     IdRubro = e.IdRubro,
                     MarcaNombre = e.Marca.Nombre,
                     RubroNombre = e.Rubro.Nombre,
                     Stock = Convert.ToDecimal(e.Stock),
                     ControlPorLote = e.ControlPorLote,
                     TieneVencimiento = e.TieneVencimiento,
                     PrecioCosto = e.PrecioCosto,
                     PrecioVenta = e.PrecioVenta,
                     Descripcion = e.Descripcion,
                     EstaEliminado = e.EstaEliminado,
                     Estado = e.Estado,
                     Medida = e.Medida,
                     UnidadMedida = e.UnidadMedida,
                     Codigo = e.Codigo,
                     CodigoBarra = e.CodigoBarra,
                     IvaIncluidoPrecioFinal = e.IvaIncluidoPrecioFinal,
                     EsFraccionable = e.EsFraccionable,
                     CategoriaIds = e.CategoriasProductos
                        .Select(cp => cp.IdCategoria)
                        .ToList()
                 })
                 .FirstOrDefault();

            return producto;
        }

        public ResultadoPaginacion<ProductoDTO> ObtenerProductos(FiltroConsulta filtros)
        {
            using var context = new GestorContextDBFactory().CreateDbContext(null);
            string collation = "Latin1_General_CI_AI";
            var query = context.Productos
                .AsNoTracking()
                .Include(e => e.Marca)
                .Include(e => e.Rubro)
                .Include(e => e.CategoriasProductos)
                .AsQueryable();

            // 🔹 FILTRO BASE
            if (filtros.Bool1)
            {
                // Mostrar discontinuados y eliminados
                query = query.Where(e =>
                    e.EstaEliminado ||
                    e.Estado == (int)EstadoProducto.Discontinuado);
            }
            else
            {
                // Ocultar eliminados y discontinuados
                query = query.Where(e =>
                    !e.EstaEliminado &&
                    e.Estado != (int)EstadoProducto.Discontinuado);
            }

            // 🔹 SOLO DISPONIBLES
            if (filtros.Bool2)
            {
                query = query.Where(e =>
                    e.Estado == (int)EstadoProducto.Disponible);
            }

            // 🔹 FILTRO ESTADO MANUAL
            if (!string.IsNullOrWhiteSpace(filtros.Filtro2?.ToString()))
            {
                if (int.TryParse(filtros.Filtro2.ToString(), out int estado))
                {
                    query = query.Where(e => e.Estado == estado);
                }
            }
            // 🔹 BUSQUEDA TEXTO
            if (!string.IsNullOrWhiteSpace(filtros.TextoBuscar))
            {
                var texto = filtros.TextoBuscar.Trim();

                switch (filtros.Filtro1?.ToString())
                {
                    case "MarcaNombre":

                        query = query.Where(e =>
                            e.Marca != null &&
                            EF.Functions.Collate(e.Marca.Nombre, collation)
                                .Contains(texto));

                        break;

                    case "RubroNombre":

                        query = query.Where(e =>
                            e.Rubro != null &&
                            EF.Functions.Collate(e.Rubro.Nombre, collation)
                                .Contains(texto));

                        break;

                    case "Codigo":

                        query = query.Where(e =>
                            EF.Functions.Collate(e.Codigo, collation)
                                .Contains(texto));

                        break;

                    case "CodigoBarra":

                        query = query.Where(e =>
                            EF.Functions.Collate(e.CodigoBarra, collation)
                                .Contains(texto));

                        break;

                    case "OfertaCodigo":

                        // Productos que componen la oferta con ese código exacto (igual para
                        // todos los tipos de oferta: todos guardan sus productos en la misma tabla).
                        query = query.Where(e =>
                            context.ProductosEnOfertasDescuentos.Any(pe =>
                                pe.ProductoId == e.ProductoId &&
                                pe.OfertaDescuento.Codigo != null &&
                                EF.Functions.Collate(pe.OfertaDescuento.Codigo, collation) == texto));

                        break;

                    case "Descripcion":

                        query = query.Where(e =>
                            EF.Functions.Collate(e.Descripcion, collation)
                                .Contains(texto));

                        break;

                    default:

                        query = query.Where(e =>
                            EF.Functions.Collate(e.Descripcion, collation).Contains(texto) ||

                            (e.Marca != null &&
                             EF.Functions.Collate(e.Marca.Nombre, collation).Contains(texto)) ||

                            (e.Rubro != null &&
                             EF.Functions.Collate(e.Rubro.Nombre, collation).Contains(texto)) ||

                            EF.Functions.Collate(e.Codigo, collation).Contains(texto) ||

                            EF.Functions.Collate(e.CodigoBarra, collation).Contains(texto));

                        break;
                }
            }

            // 🔹 FILTRO ESTADO
            if (!filtros.Bool1 && !filtros.Bool2)
            {
                if (string.IsNullOrWhiteSpace(filtros.Filtro2?.ToString()))
                {
                    query = query.Where(e => e.Estado == (int)EstadoProducto.Disponible || e.Estado == (int)EstadoProducto.SinStock || e.Estado == (int)EstadoProducto.Vencido);
                }
                else
                {
                    if (int.TryParse(filtros.Filtro2.ToString(), out int estado))
                    {
                        query = query.Where(e => e.Estado == estado);
                    }
                }
            }

            // 🔹 FILTRO MARCA
            if (!string.IsNullOrWhiteSpace(filtros.Filtro3?.ToString()))
            {
                if (long.TryParse(filtros.Filtro3.ToString(), out long marcaId))
                {
                    query = query.Where(e => e.IdMarca == marcaId);
                }
            }

            // 🔹 TOTAL
            var total = query.Count();

            // 🔹 PAGINACION SEGURA
            var totalPaginas = (int)Math.Ceiling((double)total / filtros.PageSize);

            if (totalPaginas == 0)
                totalPaginas = 1;

            if (filtros.Page > totalPaginas)
                filtros.Page = totalPaginas;

            if (filtros.Page < 1)
                filtros.Page = 1;

            // 🔹 ORDEN
            query = query
               .OrderBy(e =>
                   e.Estado == (int)EstadoProducto.Disponible ? 0 :
                   e.Estado == (int)EstadoProducto.SinStock ? 1 :
                   e.Estado == (int)EstadoProducto.Vencido ? 2 :
                   e.Estado == (int)EstadoProducto.Discontinuado ? 3 :
                   4)
               .ThenBy(e => e.Descripcion);

            // 🔹 DATA
            var data = query
                .Skip((filtros.Page - 1) * filtros.PageSize)
                .Take(filtros.PageSize)
                .Select(e => new ProductoDTO
                {
                    ProductoId = e.ProductoId,

                    IdMarca = e.IdMarca,
                    IdRubro = e.IdRubro,

                    MarcaNombre = e.Marca != null
                        ? e.Marca.Nombre
                        : string.Empty,

                    RubroNombre = e.Rubro != null
                        ? e.Rubro.Nombre
                        : string.Empty,

                    Stock = e.Stock,

                    ControlPorLote = e.ControlPorLote,

                    PrecioCosto = e.PrecioCosto,

                    PrecioVenta = e.PrecioVenta,

                    Descripcion = e.Descripcion,

                    EstaEliminado = e.EstaEliminado,

                    Estado = e.Estado,

                    Medida = e.Medida,

                    UnidadMedida = e.UnidadMedida,

                    Codigo = e.Codigo,

                    CodigoBarra = e.CodigoBarra,

                    IvaIncluidoPrecioFinal = e.IvaIncluidoPrecioFinal,

                    EsFraccionable = e.EsFraccionable,

                    CategoriaIds = e.CategoriasProductos
                        .Select(cp => cp.IdCategoria)
                        .ToList()
                })
                .ToList();

            return new ResultadoPaginacion<ProductoDTO>
            {
                Items = data,
                TotalRegistros = total,
                Page = filtros.Page,
                PageSize = filtros.PageSize
            };
        }
        public IEnumerable<ProductoOfertaDTO> ObtenerProductosPorMarcaRubroCategoriaParaOferta(
     FiltroBusquedaComboGrupo filtroGrupo)
        {
            using var context = new GestorContextDBFactory().CreateDbContext(null);

            var query = context.Productos
                .AsNoTracking()
                .Include(p => p.Marca)
                .Include(p => p.Rubro)
                .Include(p => p.CategoriasProductos)
                .Where(p => !p.EstaEliminado);

            if (filtroGrupo.IdMarca.HasValue)
            {
                query = query.Where(p => p.IdMarca == filtroGrupo.IdMarca.Value);
            }

            if (filtroGrupo.IdRubro.HasValue)
            {
                query = query.Where(p => p.IdRubro == filtroGrupo.IdRubro.Value);
            }

            if (filtroGrupo.IdCategorias.Any())
            {
                query = query.Where(p =>
                    p.CategoriasProductos.Any(cp =>
                        filtroGrupo.IdCategorias.Contains(cp.IdCategoria)));
            }

            return query
                .Select(p => new ProductoOfertaDTO
                {
                    ProductoId = p.ProductoId,
                    IdMarca = p.IdMarca,
                    IdRubro = p.IdRubro,
                    Stock = p.Stock,
                    ControlPorLote = p.ControlPorLote,
                    PrecioCosto = p.PrecioCosto,
                    PrecioVenta = p.PrecioVenta,
                    Descripcion = p.Descripcion,
                    EstaEliminado = p.EstaEliminado,
                    Estado = p.Estado,
                    Medida = p.Medida,
                    UnidadMedida = p.UnidadMedida,
                    Codigo = p.Codigo,
                    CodigoBarra = p.CodigoBarra,
                    IvaIncluidoPrecioFinal = p.IvaIncluidoPrecioFinal,
                    MarcaNombre = p.Marca != null ? p.Marca.Nombre : null,
                    RubroNombre = p.Rubro != null ? p.Rubro.Nombre : null,
                    EsFraccionable = p.EsFraccionable,
                    CategoriaIds = p.CategoriasProductos
                        .Select(cp => cp.IdCategoria)
                        .ToList()
                })
                .ToList();
        }
        public EstadoOperacion AgregarQuitarStock(MovilizacionStockDTO mStockDTO)
        {
            using var context = new GestorContextDBFactory().CreateDbContext(null);

            // Validaciones básicas
            if (mStockDTO == null)
            {
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "Datos de movimiento inválidos."
                };
            }

            if (mStockDTO.Monto <= 0)
            {
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "El monto debe ser mayor a cero."
                };
            }

            if (mStockDTO.TipoMovimientoStock != 1 && mStockDTO.TipoMovimientoStock != 2)
            {
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "Tipo de movimiento inválido."
                };
            }

            var producto = context.Productos
                .FirstOrDefault(p => p.ProductoId == mStockDTO.ProductoId && !p.EstaEliminado);

            if (producto == null)
            {
                return new EstadoOperacion
                {
                    Exitoso = false,
                    Mensaje = "Producto no encontrado."
                };
            }

            var stockAnterior = producto.Stock;

            // Movimiento
            if (mStockDTO.TipoMovimientoStock == 1) // Agregar
            {
                producto.Stock += mStockDTO.Monto;
            }
            else // Quitar
            {
                if (producto.Stock < mStockDTO.Monto)
                {
                    return new EstadoOperacion
                    {
                        Exitoso = false,
                        Mensaje = "Stock insuficiente para realizar el movimiento."
                    };
                }

                producto.Stock -= mStockDTO.Monto;
            }

            ModificarEstadoStockProductos(context);
            context.SaveChanges();


            // registrar movimiento

            return new EstadoOperacion
            {
                Exitoso = true,
                Mensaje = mStockDTO.TipoMovimientoStock == 1
                    ? "Stock agregado correctamente."
                    : "Stock descontado correctamente.",
                EntidadId = producto.ProductoId
            };
        }

        public void ModificarEstadoStockProductos(GestorContextDB context)
        {
            //using var context = new GestorContextDBFactory().CreateDbContext(null);

            // Traemos los productos activos o sin stock que no estén eliminados
            var productos = context.Productos
                .Where(p => !p.EstaEliminado &&
                           (p.Estado == (int)EstadoProducto.Disponible || p.Estado == (int)EstadoProducto.SinStock))
                .ToList();

            foreach (var p in productos)
            {
                // CASO A: Tiene stock pero figura como "Sin Stock" -> Corregir a Disponible
                if (p.Stock > 0 && p.Estado == (int)EstadoProducto.SinStock)
                {
                    p.Estado = (int)EstadoProducto.Disponible;
                }

                // CASO B: No tiene stock pero figura como "Disponible" -> Corregir a Sin Stock
                else if (p.Stock <= 0 && p.Estado == (int)EstadoProducto.Disponible)
                {
                    p.Estado = (int)EstadoProducto.SinStock;
                }
            }

            //context.SaveChanges();
        }
    }
}
