﻿using Servicios.Helpers.Sistema;
using Servicios.Helpers.Sistema.Admin;
using Servicios.Helpers.Sistema.FiltrosConsulta;
using Servicios.LogicaNegocio.Producto.DTO;
using Servicios.LogicaNegocio.Venta.DTO;
using Servicios.LogicaNegocio.Venta.Oferta.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Servicios.LogicaNegocio.Venta.Oferta
{
    public interface IOfertaServicio
    {
        ResultadoPaginacion<OfertaDTO> ObtenerOfertas(FiltroConsulta filtros, bool vieneDeVenta);
        EstadoOperacion Insertar(OfertaDTO dto);
        //public OfertaDTO ObtenerOfertaActivaPorId(long idOFerta);
        ItemVentaDTO? ObtenerItemVentaOferta(long ofertaId);
        List<OfertaDTO> ObtenerOfertasVencidas(int diasHaciaAdelante);
        List<OfertaBajoStockDTO> ObtenerOfertasConBajoStock();
        EstadoOperacion ActivarDesactivarOferta(long ofertaId);

        //public InfoOfertaDTO ObtenerInfoOferta();
        //public List<OfertaDTO> ObtenerOfertasActivas(string cadenaBuscar);
        //public List<OfertaDTO> ObtenerOfertasActivasCompuestas(string cadenaBuscar, string columna, DateTime? fechaDesde, DateTime? fechaHasta);
        //public List<OfertaDTO> ObtenerOfertasInactivas(string cadenaBuscar);
        //public List<OfertaDTO> ObtenerOfertasInactivasCompuesta(string cadenaBuscar, string columna, DateTime? fechaDesde, DateTime? fechaHasta);
        //public List<InformacionExistenciaOfertaDescuentoProducto> ObtenerProductosEnOferta(List<ProductoDTO> productosDentroOferta);
        //public OfertaDTO ObtenerOfertaPorId(long idOFerta);
        //public List<OfertaDTO> ObtenerOfertasActivasInactivas(string cadenaBuscar, string columna, DateTime? fechaDesde, DateTime? fechaHasta);
        //public OfertaDTO? ActivarDesactivar(long ofertaId);
        //public bool ExisteOfertaPorCodigo(string codigo);
    }
}
