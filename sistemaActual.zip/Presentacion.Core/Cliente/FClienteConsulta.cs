﻿using AccesoDatos.Entidades;
using Presentacion.Core.CuentaCorriente;
using Presentacion.Core.Presentacion.Core.Helpers;
using Presentacion.FBase;
using Presentacion.FBase.Helpers;
using Presentacion.FormulariosBase.Helpers;
using Servicios.Helpers.Cliente;
using Servicios.Helpers.Producto;
using Servicios.Helpers.Sistema.FiltrosConsulta;
using Servicios.LogicaNegocio.Cliente;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Presentacion.Core.Cliente
{
    public partial class FClienteConsulta : FBaseConsulta
    {
        private readonly IClienteServicio _clienteServicio;

        private bool vieneDeCargaCliente = false;
        private bool vieneDeCtacte = false;

        public long? clienteSeleccionado = null;

        public FClienteConsulta() : this(new ClienteServicio())
        {
            InitializeComponent();
        }

        public FClienteConsulta(IClienteServicio clienteServicio)
        {
            _clienteServicio = clienteServicio;

            InitializeComponent();
        }

        public FClienteConsulta(bool _vieneDeCargaCliente) : this(new ClienteServicio())
        {
            vieneDeCargaCliente = _vieneDeCargaCliente;

            InitializeComponent();
        }

        public FClienteConsulta(bool _vieneDeCtacte, int x) : this(new ClienteServicio())
        {
            vieneDeCtacte = _vieneDeCtacte;

            InitializeComponent();
        }

        #region LOAD

        private void FClienteConsulta_Load(object sender, EventArgs e)
        {

        }

        #endregion

        #region CONFIG FILTROS
        protected override string TextoLblBuscar
    => "Buscar Cliente:";

        protected override string TextoLblCbx1
            => "Buscar por Propiedad";

        protected override string TextoLblCbx2
            => "Filtrar por Estado";

        protected override string TextoLblCbx3
            => "Filtrar por Fecha";

        protected override string TextoTitular
          => "Listado de Clientes";
        protected override void ConfigurarFiltrosUI()
        {
            base.ConfigurarFiltrosUI();

            // =========================
            // COMBO BUSQUEDA
            // =========================
            ActivarCheck(chkBool1, "Mostrar Eliminados");
            ActivarCheck(chkBool2, "Mostrar Todos los Clientes");
            var opcionesBusqueda = new List<OpcionFiltro>
            {
                new OpcionFiltro { Texto = "Todos", Valor = "" },
                new OpcionFiltro { Texto = "Nombre", Valor = "ApyNom" },
                new OpcionFiltro { Texto = "Documento", Valor = "Dni" },
                new OpcionFiltro { Texto = "Teléfono", Valor = "Telefono" },
                new OpcionFiltro { Texto = "Email", Valor = "Email" }
            };

            ActivarCombo(
                cbx1,
                lblcbx1,
                opcionesBusqueda,
                "Texto",
                "Valor",
                "Buscar cliente por:"
            );

            // =========================
            // FILTRO FECHAS
            // =========================

            ActivarFiltroFechas("Filtrar por fecha");

            // =========================
            // COMBO TIPO FILTRO
            // =========================

            var estado = new List<OpcionFiltro>
             {
                 new OpcionFiltro { Texto = "Todas", Valor = "" },

                 new OpcionFiltro
                 {
                     Texto = "Activos",
                     Valor = ((int)TipoFiltroCliente.Activo).ToString()
                 },
                 new OpcionFiltro
                 {
                     Texto = "Baja",
                     Valor = ((int)TipoFiltroCliente.Baja).ToString()
                 },

                 new OpcionFiltro
                 {
                     Texto = "Inhabilitado",
                     Valor = ((int)TipoFiltroCliente.Inhabilitado).ToString()
                 },

                 new OpcionFiltro
                 {
                     Texto = "Con Cuenta Corriente",
                     Valor = ((int)TipoFiltroCliente.ConCtaCte).ToString()
                 },

                 new OpcionFiltro
                 {
                     Texto = "Sin Cuenta Corriente",
                     Valor = ((int)TipoFiltroCliente.SinCtaCte).ToString()
                 }
             };

            ActivarCombo(
                cbx2,
                lblcbx2,
                estado,
                "Texto",
                "Valor",
                "Tipo de filtrado:"
            );

            var fechaFiltro = new List<OpcionFiltro>
            {
                new OpcionFiltro { Texto = "Todas", Valor = "" },

                new OpcionFiltro
                {
                    Texto = "Fecha Alta",
                    Valor = ((int)TipoFiltroCliente.FechaAlta).ToString()
                },

                new OpcionFiltro
                {
                    Texto = "Fecha Baja",
                    Valor = ((int)TipoFiltroCliente.FechaBaja).ToString()
                },
            };
            ActivarCombo(
               cbx3,
               lblcbx3,
               fechaFiltro,
               "Texto",
               "Valor",
               "Tipo de Fecha:"
           );

            // =========================
            // CHECK ELIMINADOS
            // =========================

            ActivarCheck(chkBool1, "Ver eliminados");

            // =========================
            // VALORES DEFAULT
            // =========================

            cbx1.SelectedValue = "";
            cbx2.SelectedValue = "";
            cbx3.SelectedValue = "";
        }

        #endregion
        protected override void AccionCheck2()
        {
            if (chkBool2.Checked)
            {
                _actualizandoFiltros = true;

                chkBool1.Checked = false;

                _actualizandoFiltros = false;

                LimpiarFiltrosEspeciales();
            }
        }
        protected override void AccionCheck1()
        {
            if (chkBool1.Checked)
            {
                _actualizandoFiltros = true;

                chkBool2.Checked = false;

                _actualizandoFiltros = false;

                LimpiarFiltrosEspeciales();
            }
        }

        private void LimpiarFiltrosEspeciales()
        {
            _actualizandoFiltros = true;

            txtBuscar.Clear();

            if (cbx1.Enabled)
                cbx1.SelectedIndex = 0;

            if (cbx2.Enabled)
                cbx2.SelectedIndex = 0;

            if (cbx3.Enabled)
                cbx3.SelectedIndex = 0;

            chkUsarFecha.Checked = false;

            _actualizandoFiltros = false;
        }
        #region FILTROS

        protected override FiltroConsulta ObtenerFiltros()
        {
            var filtros = base.ObtenerFiltros();

            // Si no selecciona nada en combo búsqueda
            // usar ApyNom por defecto

            if (filtros.Filtro1 == null ||
                string.IsNullOrWhiteSpace(filtros.Filtro1.ToString()))
            {
                filtros.Filtro1 = "ApyNom";
            }

            return filtros;
        }

        protected override bool EsModoSoloLectura(FiltroConsulta filtro)
        {
            return filtro.Bool1;
        }

        #endregion

        #region ACTUALIZAR DATOS

        public override void ActualizarDatos(DataGridView dgv, FiltroConsulta filtros)
        {
            base.ActualizarDatos(dgv, filtros);

            var resultado = _clienteServicio.ObtenerClientes(filtros);

            dgv.DataSource = resultado.Items;

            ResetearGrilla(dgv);

            var paginacion = new DatosPaginacion
            {
                PaginaActual = resultado.Page,
                PageSize = resultado.PageSize,
                CantidadRegistros = resultado.TotalRegistros,
            };

            ActualizarPaginacionUI(paginacion);

            BarraLateralBotones.Enabled = !filtros.Bool1;
        }

        #endregion

        #region RESET GRILLA

        public override void ResetearGrilla(DataGridView grilla)
        {
            base.ResetearGrilla(grilla);

            if (grilla.Columns.Count == 0)
                return;

            grilla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            if (grilla.Columns.Contains("PersonaId"))
            {
                grilla.Columns["PersonaId"].Visible = false;
                grilla.Columns["PersonaId"].Name = "Id";
            }

            if (grilla.Columns.Contains("Nombre"))
                //ColumnaFill(grilla.Columns["Nombre"], 100, 70);
                grilla.Columns["Nombre"].Visible = false;

            if (grilla.Columns.Contains("Apellido"))
                //ColumnaFill(grilla.Columns["Apellido"], 100, 70);
                grilla.Columns["Apellido"].Visible = false;

            if(grilla.Columns.Contains("Nombre") && grilla.Columns.Contains("Apellido"))
                grilla.Columns["NombreCompleto"].HeaderText = "Nombre";
                ColumnaFill(grilla.Columns["NombreCompleto"], 90, 80);

            if (grilla.Columns.Contains("Dni"))
                ColumnaFill(grilla.Columns["Dni"], 70, 60, "DNI");

            if (grilla.Columns.Contains("Email"))
                ColumnaFill(grilla.Columns["Email"], 90, 80);

            if (grilla.Columns.Contains("Telefono"))
                ColumnaFill(grilla.Columns["Telefono"], 40, 30, "Teléfono");

            if (grilla.Columns.Contains("EstadoDescripcion"))
                ColumnaFill(grilla.Columns["EstadoDescripcion"], 70, 60, "Estado Cliente");

            if (grilla.Columns.Contains("TieneCuentaCorriente"))
                ColumnaFill(grilla.Columns["TieneCuentaCorriente"], 70, 60, "Cuenta Corriente");

            if (grilla.Columns.Contains("DescripcionEstadoCtaCte"))
                ColumnaFill(grilla.Columns["DescripcionEstadoCtaCte"], 80, 60, "Estado Cuenta Corriente");
            

            if (grilla.Columns.Contains("Estado"))
                grilla.Columns["Estado"].Visible = false;

            if (grilla.Columns.Contains("EstaEliminado"))
                grilla.Columns["EstaEliminado"].Visible = false;
        }
        #endregion

        #region BOTONES BASE

        public override void EjecutarBtnNuevo()
        {
            var f = new FClienteABM(TipoOperacion.Nuevo);
            f.ShowDialog();
            if (f.RealizoAlgunaOperacion)
                RefrescarGrilla();
        }

        public override void EjecutarBtnModificar()
        {
            base.EjecutarBtnModificar();

            if (!puedeEjecutarComando)
                return;

            var f = new FClienteABM(TipoOperacion.Modificar, entidadID);

            f.ShowDialog();

            if (f.RealizoAlgunaOperacion)
                RefrescarGrilla();
        }

        public override void EjecutarBtnEliminar()
        {
            base.EjecutarBtnEliminar();

            if (!puedeEjecutarComando)
                return;

            var f = new FClienteABM(TipoOperacion.Eliminar, entidadID);

            f.ShowDialog();

            if (f.RealizoAlgunaOperacion)
                f.Close();
            RefrescarGrilla();
        }

        #endregion

        #region ACCIONES PERSONALIZADAS

        protected override void ConfigurarAccionesPersonalizadas()
        {
            if (vieneDeCargaCliente)
            {
                AgregarAccion(
                    "Seleccionar Cliente",
                    Constantes.Imagenes.ImgSumar,
                    SeleccionarCliente,
                    true
                );
            }

            AgregarAccion(
            "Asignar Cta Cte",
            Constantes.Imagenes.ImgNuevo,
            SeleccionarClienteParaCtaCte,
            true
            );
            AgregarAccion(
            "Detalles Cta Cte",
            Constantes.Imagenes.ImgMovimiento,
            AbrirDetalleCtaCte,
            true
            );
        }

        private void SeleccionarCliente(long? id)
        {
            ControlCargaExistencaDatos();

            if (!puedeEjecutarComando)
                return;

            clienteSeleccionado = id;

            DialogResult = DialogResult.OK;

            Close();
        }
        private void AbrirDetalleCtaCte(long? id)
        {
            clienteSeleccionado = id;
            if (clienteSeleccionado == null)
            {
                Informar("Seleccione un cliente para ver los detalles de su cuenta corriente.", "Atención");
                //MessageBox.Show("Seleccione un cliente para ver los detalles de su cuenta corriente.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {

                var response = _clienteServicio.ObtenerCtaCteIdPorClienteId((long)clienteSeleccionado);
                if (!response.Exitoso)
                {
                    Informar("El cliente seleccionado no tiene una cuenta corriente asociada.", "Atención");
                    //MessageBox.Show("El cliente seleccionado no tiene una cuenta corriente asociada.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {

                    var f = new FCuentaCorrienteABM(TipoOperacion.Modificar, null, response.EntidadId);
                    f.ShowDialog();

                    // Activar / cerrar / reabrir cambian datos sin pasar por "Modificar":
                    // se refresca siempre al volver de la cuenta corriente.
                    RefrescarGrilla();

                }
            }
        }


        private void SeleccionarClienteParaCtaCte(long? id)
        {
            ControlCargaExistencaDatos();

            if (!puedeEjecutarComando)
                return;

            clienteSeleccionado = id;

            var cliente = _clienteServicio.ObtenerClientePorId(id.Value);

            if (cliente.CuentaCorrienteId != null)
            {
                Informar("El cliente seleccionado ya tiene una cuenta corriente asociada.", "Advertencia");
                //MessageBox.Show(
                //    "El cliente seleccionado ya tiene una cuenta corriente asociada.", 
                //    "Advertencia",                                                          
                //    MessageBoxButtons.OK,                                    
                //    MessageBoxIcon.Warning
                //);

                return;
            }
            if (cliente.Telefono == "00000000" && cliente.Telefono2 == "00000000" && cliente.Email == "Sin Asignar")
            {
                Informar("El cliente seleccionado no tiene información de contacto válida. Agregar un medio de contacto por favor.", "Advertencia");
                //MessageBox.Show(
                //    "El cliente seleccionado no tiene información de contacto válida. Agregar un medio de contacto por favor.", 
                //    "Advertencia",                                                          
                //    MessageBoxButtons.OK,                                    
                //    MessageBoxIcon.Warning
                //);
                return;
            }
            var fCtacte = new FCuentaCorrienteABM(TipoOperacion.Nuevo, clienteSeleccionado, null);

            if (fCtacte.ShowDialog() == DialogResult.OK &&
                fCtacte.RealizoAlgunaOperacion)
            {
                RefrescarGrilla();
            }
        }

        #endregion

        #region VALIDACIONES

        public void ControlCargaExistencaDatos()
        {
            if (dgvGrilla.RowCount == 0)
            {
                Informar("No hay datos cargados.", "Error");
                //MessageBox.Show("No hay datos cargados.");

                puedeEjecutarComando = false;

                return;
            }

            if (!entidadID.HasValue)
            {
                Informar("Seleccione un registro.", "Error");
                //MessageBox.Show("Seleccione un registro.");

                puedeEjecutarComando = false;

                return;
            }

            puedeEjecutarComando = true;
        }

        #endregion
    }
}