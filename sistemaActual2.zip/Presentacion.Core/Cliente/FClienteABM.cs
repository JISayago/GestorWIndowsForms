﻿using AccesoDatos.Entidades;
using Presentacion.Core.CuentaCorriente;
using Presentacion.FBase;
using Presentacion.FBase.Helpers;
using Presentacion.FormulariosBase.Helpers;
using Servicios.Helpers.Cliente;
using Servicios.LogicaNegocio.Articulo.Marca;
using Servicios.LogicaNegocio.Cliente;
using Servicios.LogicaNegocio.Cliente.DTO;
using Servicios.LogicaNegocio.CuentaCorriente;

namespace Presentacion.Core.Cliente
{
    public partial class FClienteABM : FBaseABM
    {
        public FClienteABM()
        {
            InitializeComponent();
        }
        private readonly IClienteServicio _clienteServicio;

        public override void FBaseABM_Load(object sender, EventArgs e)
        {
            base.FBaseABM_Load(sender, e);
            Inicializador(EntidadID);
        }
        public FClienteABM(TipoOperacion tipoOperacion, long? entidadID = null) : base(tipoOperacion, entidadID)
        {
            InitializeComponent();
            _clienteServicio = new ClienteServicio();

            if (tipoOperacion == TipoOperacion.Eliminar || tipoOperacion == TipoOperacion.Modificar)
            {
                CargarDatos(entidadID);
            }

            if (tipoOperacion == TipoOperacion.Eliminar)
            {
                DesactivarControles(this);
            }

            AgregarControlesObligatorios(txtNombre, "Nombre");
            AgregarControlesObligatorios(txtApellido, "Apellido");
            AgregarControlesObligatorios(txtDni, "DNI", Validaciones.SoloNumeros, Validaciones.Longitud(7, 8));
            AgregarControlesObligatorios(dtpFNacimiento, "Fecha de nacimiento", Validaciones.FechaNoFutura);
            AgregarValidacionOpcional(txtEmail, "Email", Validaciones.Email);
            AgregarValidacionOpcional(txtTelefono, "Teléfono", Validaciones.SoloNumeros, Validaciones.MayorACero);
            AgregarValidacionOpcional(txtCelular, "Celular", Validaciones.SoloNumeros, Validaciones.MayorACero);
        }
        public override void Inicializador(long? entidadId)
        {

        }

        public override void CargarDatos(long? entidadId)
        {
            if (!entidadId.HasValue)
            {
                MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                this.Close();
            }

            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                btnLimpiar.Enabled = false;
            }
           
            var cliente = _clienteServicio.ObtenerClientePorId(entidadId.Value);

            // Datos Personales
            txtApellido.Text = cliente.Apellido;
            txtNombre.Text = cliente.Nombre;
            txtDireccion.Text = cliente.Direccion;
            txtCelular.Text = cliente.Telefono2;
            txtCuil.Text = cliente.Cuil;
            txtDni.Text = cliente.Dni;
            txtEmail.Text = cliente.Email;
            dtpFNacimiento.Value = (DateTime)cliente.FechaNacimiento;
            txtTelefono.Text = cliente.Telefono;
            // Datos Cliente
        }


        public override bool EjecutarComandoNuevo()
        {

            if (!VerificarDatosObligatorios())
            {
                MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            if (string.IsNullOrEmpty(txtEmail.Text) && string.IsNullOrEmpty(txtCelular.Text) && string.IsNullOrEmpty(txtTelefono.Text))
            {
                var respuesta = MessageBox.Show(@"Se recomienda al menos un medio de contacto(Telefono, Email, Celular, etc) para la apertura de una cuenta corriente", @"Atención", MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning);
                if (respuesta != DialogResult.OK)
                {
                    return false;
                }
            }

            var nuevoCliente = new ClienteDTO
            {
                Apellido = txtApellido.Text,
                Nombre = txtNombre.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtCelular.Text,
                Cuil = txtCuil.Text,
                Dni = txtDni.Text,
                Email = txtEmail.Text,
                FechaNacimiento = dtpFNacimiento.Value,
                Telefono2 = txtCelular.Text,
                NumeroCliente = string.Empty, //Asignar un valor adecuado si es necesario
                Estado = (int)EstadoCliente.Activo, //Activo por defecto pensar la logica de creacion si entra activa o no
                //CuentaCorrienteId = cmbCuentaCorriente.SelectedValue != null ? (long?)cmbCuentaCorriente.SelectedValue : null,
                EstaEliminado = false,
            };

            var response = _clienteServicio.Insertar(nuevoCliente);

            if (response.Exitoso)
            {
                MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                   MessageBoxIcon.Information);
                RealizoAlgunaOperacion = true;
                this.Close();
                return true;
            }
            else
            {
                MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                   MessageBoxIcon.Error);
                RealizoAlgunaOperacion  = false;
                this.Close();
                return false;
            }
        }

        public override bool EjecutarComandoEliminar()
        {
            if (!EntidadID.HasValue)
            {
                MessageBox.Show(@"´Por favor seleccione un cliente válido.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                var response = _clienteServicio.Eliminar((long)EntidadID);
                if (response.Exitoso)
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;
        }
        public override bool EjecutarComandoModificar()
        {
            if (!EntidadID.HasValue)
            {
                MessageBox.Show(@"´Por favor seleccione un cliente válido.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Modificar)
            {

                var clienteEditar = new ClienteDTO
                {
                    Apellido = txtApellido.Text,
                    Nombre = txtNombre.Text,
                    Direccion = txtDireccion.Text,
                    Telefono = txtTelefono.Text,
                    Cuil = txtCuil.Text,
                    Dni = txtDni.Text,
                    Email = txtEmail.Text,
                    FechaNacimiento = dtpFNacimiento.Value,
                    Telefono2 = txtCelular.Text,
                    Estado = (int)EstadoCliente.Activo,
                    EstaEliminado = false
                };

                var response = _clienteServicio.Modificar(clienteEditar, EntidadID);

                if (response.Exitoso)
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;
        }

        private void btnCuentaCorriente_Click(object sender, EventArgs e)
        {
            //var fCuentaCorriente = new FCuentaCorrienteConsulta();
            //fCuentaCorriente.ShowDialog();
        }



    }
}
