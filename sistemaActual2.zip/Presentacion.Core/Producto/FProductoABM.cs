﻿using AccesoDatos.Entidades;
using Presentacion.Core.Producto.Categoria;
using Presentacion.Core.Producto.Marca;
using Presentacion.FBase;
using Presentacion.FBase.Helpers;
using Presentacion.FormulariosBase.Helpers;
using Servicios.Helpers.Producto;
using Servicios.Helpers.Sistema.FiltrosConsulta;
using Servicios.LogicaNegocio.Articulo.Marca;
using Servicios.LogicaNegocio.Producto;
using Servicios.LogicaNegocio.Producto.DTO;
using Servicios.LogicaNegocio.Producto.Rubro;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion.Core.Producto
{
    public partial class FProductoABM : FBaseABM
    {
        private readonly IProductoServicio _ProductoServicio;
        private readonly IMarcaServicio _MarcaServicio;
        private readonly IRubroServicio _RubroServicio;
        protected long? EntidadID;
        private List<long> _categoriasSeleccionadas = new List<long>();
        private long _marcaID = 0;
        private long _rubroID = 0;
        private bool _cargandoDatos = false;

        public override void FBaseABM_Load(object sender, EventArgs e)
        {
            base.FBaseABM_Load(sender, e);
            Inicializador(EntidadID);
        }

        public FProductoABM(TipoOperacion tipoOperacion, long? entidadId = null)
            : base(tipoOperacion, entidadId)
        {
            InitializeComponent();

            _ProductoServicio = new ProductoServicio();
            _MarcaServicio = new MarcaServicio();
            _RubroServicio = new RubroServicio();
            EntidadID = entidadId;

            _cargandoDatos = true; // Indicador para evitar eventos durante la carga de datos

            if (tipoOperacion == TipoOperacion.Eliminar || tipoOperacion == TipoOperacion.Modificar)
            {
                CargarDatos(entidadId);
            }

            if (tipoOperacion == TipoOperacion.Eliminar)
            {
                DesactivarControles(this);
            }
            AgregarControlesObligatorios(txtProducto, "Detalle del Producto");
            AgregarControlesObligatorios(txtCodigo, "Detalle del Producto");
            AgregarControlesObligatorios(txtCodigoBarra, "Detalle del Producto");
            AgregarControlesObligatorios(txtPrecioCosto, "Precio Costo", Validaciones.DecimalMayorACero, Validaciones.DecimalConMaxDecimales(2));
            AgregarControlesObligatorios(txtPrecioVenta, "Precio Venta", Validaciones.DecimalMayorACero, Validaciones.DecimalConMaxDecimales(2));

            var filtrosMarca = new FiltroConsulta
            {
                TextoBuscar = "",
                Page = 1,
                PageSize = int.MaxValue,
                Bool1 = false // no eliminados
            };

            var marcas = _MarcaServicio
                .ObtenerMarcas(filtrosMarca)
                .Items
                .ToList();

            //cmbMarca.DisplayMember = "Nombre"; // lo que se muestra
            //cmbMarca.ValueMember = "Id";
            //cmbMarca.DataSource = marcas;

            //cmbMarca.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //cmbMarca.AutoCompleteSource = AutoCompleteSource.ListItems;
            //cmbMarca.DropDownStyle = ComboBoxStyle.DropDown;

            var filtrosRubros = new FiltroConsulta
            {
                TextoBuscar = string.Empty,
                Bool1 = false, // no eliminados
                Page = 1,
                PageSize = 1000
            };

            var rubros = _RubroServicio
                .ObtenerRubros(filtrosRubros)
                .Items
                .ToList();

            //cmbRubro.DisplayMember = "Nombre"; // lo que se muestra
            //cmbRubro.ValueMember = "Id";
            //cmbRubro.DataSource = rubros;

            //cmbRubro.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //cmbRubro.AutoCompleteSource = AutoCompleteSource.ListItems;
            //cmbRubro.DropDownStyle = ComboBoxStyle.DropDown;

            EntidadID = entidadId;
            _cargandoDatos = false; // Fin de la carga de datos
            txtStock.Enabled = false;
        }

        public override void Inicializador(long? entidadId)
        {
            /*if (entidadId.HasValue) return;

            txtProducto.KeyPress += Validacion.NoSimbolos;
            txtProducto.KeyPress += Validacion.NoNumeros;
            */
        }

        public override void DesactivarControles(object obj)
        {
            base.DesactivarControles(obj);

            btnLimpiar.Enabled = false;
            btnLimpiar.Visible = false;
        }

        public override void CargarDatos(long? entidadId)
        {
            if (!entidadId.HasValue)
            {
                MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                this.Close();
            }

            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                btnLimpiar.Enabled = false;
            }

            var Producto = _ProductoServicio.ObtenerProductoPorId(entidadId.Value);

            if (Producto != null)
            {
                txtProducto.Text = Producto.Descripcion;
                chkbProductoDiscontinuado.Checked = Producto.Estado == (int)EstadoProducto.Discontinuado; // Si el estado es 3, marcamos como discontinuado
                //txtEstado.Text = Producto.Estado.ToString();
                txtMedida.Text = Producto.Medida;
                txtUnidadMedida.Text = Producto.UnidadMedida;
                txtStock.Text = Producto.Stock.ToString();
                txtStock.Enabled = false; // Si el producto tiene control por lote, deshabilitamos el campo de stock
                txtPrecioCosto.Text = Producto.PrecioCosto.ToString();
                txtPrecioVenta.Text = Producto.PrecioVenta.ToString();
                txtCodigo.Text = Producto.Codigo;
                txtCodigoBarra.Text = Producto.CodigoBarra;
                chkIvaIncluido.Checked = Producto.IvaIncluidoPrecioFinal;
                chkEsFraccionable.Checked = Producto.EsFraccionable;
                chkControlPorLotes.Checked = Producto.ControlPorLote;
                chkTieneVencimiento.Checked = Producto.TieneVencimiento;

                // Precargamos las categorías que ya tiene asignadas el producto,
                // para no perderlas si se guarda sin abrir el diálogo de Categorias.
                _categoriasSeleccionadas = Producto.CategoriaIds?.ToList() ?? new List<long>();
                var marca = Producto.IdMarca > 0 ? _MarcaServicio.ObtenerPorId(Producto.IdMarca) : null;
                MostrarDatosBoton(Producto.IdMarca, marca?.Nombre ?? string.Empty, btnMarca);
                var rubro = Producto.IdRubro > 0 ? _RubroServicio.ObtenerPorId(Producto.IdRubro) : null;
                MostrarDatosBoton(Producto.IdRubro, rubro?.Nombre ?? string.Empty, btnRubro);
                var categorias = _categoriasSeleccionadas.Any() ? $"Cantdidad:{_categoriasSeleccionadas.Count()}" : "Ninguna";
                MostrarDatosBoton(0, categorias, btnCategorias);

            }
            else
            {
                MessageBox.Show(@"Ocurrio un Error Grave", @"Error Grave", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }
        private void MostrarDatosBoton(long id, string nombre, Button btn)
        {
            
            switch (btn.Name)
            {
                case "btnMarca":
                    _marcaID = id;
                    break;
                case "btnRubro":
                    _rubroID = id;
                    break;
                case "btnCategorias":
                    // No hacemos nada con el ID aquí, ya que las categorías se manejan en la lista _categoriasSeleccionadas
                    break;
                default:
                    throw new ArgumentException("Botón no reconocido");
            }

            btn.Text = nombre;
        }
        public override bool EjecutarComandoNuevo()
        {
            if (!VerificarDatosObligatorios())
            {
                MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            if (_marcaID <= 0)
            {
                MessageBox.Show(@"Seleccione una marca.", @"Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (_rubroID <= 0)
            {
                MessageBox.Show(@"Seleccione un rubro.", @"Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            var ProductoNueva = new ProductoDTO
            {
                Descripcion = txtProducto.Text,
                Stock = 0,
                PrecioCosto = decimal.Parse(txtPrecioCosto.Text),
                PrecioVenta = decimal.Parse(txtPrecioVenta.Text),
                Estado = chkbProductoDiscontinuado.Checked ? (int)EstadoProducto.Discontinuado : (int)EstadoProducto.Disponible, // Si el producto está marcado como discontinuado, asignamos el estado 3, de lo contrario, 1 (activo)
                Medida = txtMedida.Text,
                UnidadMedida = txtUnidadMedida.Text,
                Codigo = txtCodigo.Text,
                CodigoBarra = txtCodigoBarra.Text,
                IvaIncluidoPrecioFinal = chkIvaIncluido.Checked,
                EsFraccionable = chkEsFraccionable.Checked,
                IdMarca = _marcaID,
                IdRubro = _rubroID,
                CategoriaIds = _categoriasSeleccionadas.ToList(),
                EstaEliminado = false,
                ControlPorLote = chkControlPorLotes.Checked,
                TieneVencimiento = chkTieneVencimiento.Checked
            };

            //ARREGLAR LOS PARSE y TIPOS DE DATOS

            var response = _ProductoServicio.Insertar(ProductoNueva);

            if (response.Exitoso)
            {
                MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                   MessageBoxIcon.Information);
                return true;
            }
            else
            {
                MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                   MessageBoxIcon.Error);
                return false;
            }

        }

        public override bool EjecutarComandoEliminar()
        {
            if (!EntidadID.HasValue)
            {
                MessageBox.Show(@"´Por favor seleccione una Producto válida.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return false;

            }
            if (TipoOperacion == TipoOperacion.Eliminar)
            {
                var response = _ProductoServicio.Eliminar((long)EntidadID);
                if (response.Exitoso)
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
                    return false;
                }

            }
            return false;

        }

        public override bool EjecutarComandoModificar()
        {
            if (!VerificarDatosObligatorios())
            {
                MessageBox.Show(@"Por favor ingrese los campos Obligatorios.", @"Atención", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }

            if (TipoOperacion == TipoOperacion.Modificar)
            {
                if (!EntidadID.HasValue)
                {
                    MessageBox.Show(@"´Por favor seleccione un Producto válida.", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return false;

                }
                if (_marcaID <= 0)
                {
                    MessageBox.Show(@"Seleccione una marca.", @"Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                if (_rubroID <= 0)
                {
                    MessageBox.Show(@"Seleccione un rubro.", @"Atención", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                //ARREGLAR LOS PARSE y TIPOS DE DATOS
                var ProductoModificar = new ProductoDTO //completar con los datos del producto a modificar
                {
                    Descripcion = txtProducto.Text,
                    Stock = decimal.Parse(txtStock.Text),
                    PrecioCosto = decimal.Parse(txtPrecioCosto.Text),
                    PrecioVenta = decimal.Parse(txtPrecioVenta.Text),
                    Estado = chkbProductoDiscontinuado.Checked ? (int)EstadoProducto.Discontinuado : (int)EstadoProducto.Disponible,
                    Medida = txtMedida.Text,
                    UnidadMedida = txtUnidadMedida.Text,
                    Codigo = txtCodigo.Text,
                    CodigoBarra = txtCodigoBarra.Text,
                    IvaIncluidoPrecioFinal = chkIvaIncluido.Checked,
                    EsFraccionable = chkEsFraccionable.Checked,
                    IdMarca = _marcaID,
                    IdRubro = _rubroID,
                    CategoriaIds = _categoriasSeleccionadas.ToList(),
                    EstaEliminado = false,
                    ControlPorLote = chkControlPorLotes.Checked,
                    TieneVencimiento = chkTieneVencimiento.Checked
                };

                var response = _ProductoServicio.Modificar(ProductoModificar, EntidadID);

                if (response.Exitoso)
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return true;
                }
                else
                {
                    MessageBox.Show($"{response.Mensaje}", @"Atención", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return false;
                }

            }
            return true;

        }

        //private void btnCategorias_Click(object sender, EventArgs e)
        //{
        //    //si existe el id recien entrar a fcategoriaProducto

        //    var fCategoriaProducto = new Categoria.FAsignacionCategoriaProducto(EntidadID);

        //    if (fCategoriaProducto.ShowDialog() == DialogResult.OK)
        //    {
        //        // Guardamos internamente las categorías elegidas por el usuario
        //        _categoriasSeleccionadas = fCategoriaProducto.CategoriasSeleccionadas;

        //        // Si querés mostrarlas en una textbox invisible o label:
        //        //txtCategoria.Text = string.Join(",", _categoriasSeleccionadas);
        //    }
        //}
        private void btnCategorias_Click(object sender, EventArgs e)
        {
            using (var fCategorias = new FAsignacionCategoria(_categoriasSeleccionadas))
            {
                if (fCategorias.ShowDialog() == DialogResult.OK)
                    _categoriasSeleccionadas = fCategorias.IdsSeleccionados;
                MostrarDatosBoton(0, $"Cantidad:{_categoriasSeleccionadas.Count()}", btnCategorias);
            }
        }

        private void chkControlPorLotes_CheckedChanged(object sender, EventArgs e)
        {
            if (_cargandoDatos) return;

            if (TipoOperacion == TipoOperacion.Modificar)
            {
                var checkbox = (CheckBox)sender;
                string accion = checkbox.Checked ? "activar" : "desactivar";
                string mensaje = checkbox.Checked
                    ? "Al activar el control por lotes, se reiniciara el stock actual del producto. ¿Desea continuar?"
                    : "Al desactivar el control por lotes, se reiniciara el stock del producto y se deben deshabilitar los lotes asociados. ¿Desea continuar?";

                var mensajeConfirmacion = MessageBox.Show(mensaje, "Confirmación", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

                if (mensajeConfirmacion == DialogResult.OK)
                {
                    // Si acepta, ejecutamos la lógica
                    txtStock.Enabled = !checkbox.Checked;
                    txtStock.Text = "0";
                }
                else
                {
                    _cargandoDatos = true; // Apagamos los eventos temporalmente

                    checkbox.Checked = !checkbox.Checked; // Revertimos el cambio

                    _cargandoDatos = false; // Prendemos los eventos de nuevo
                }
            }
        }

        private void btnMarca_Click(object sender, EventArgs e)
        {
            using (var f = new FAsignacionMarca(_marcaID > 0 ? _marcaID : (long?)null))
            {
                if (f.ShowDialog() == DialogResult.OK && f.IdSeleccionado.HasValue)
                    MostrarDatosBoton(f.IdSeleccionado.Value, f.DescripcionSeleccionada,btnMarca);
            }
        }

        private void btnRubro_Click(object sender, EventArgs e)
        {

            using (var f = new FAsignacionRubro(_rubroID > 0 ? _rubroID : (long?)null))
            {
                if (f.ShowDialog() == DialogResult.OK && f.IdSeleccionado.HasValue)
                    MostrarDatosBoton(f.IdSeleccionado.Value, f.DescripcionSeleccionada, btnRubro);
            }

        }
    }
}
